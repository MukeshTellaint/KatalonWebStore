import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.TestObject as TestObject

import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.annotation.BeforeTestCase
import com.kms.katalon.core.annotation.BeforeTestSuite
import com.kms.katalon.core.annotation.AfterTestCase
import com.kms.katalon.core.annotation.AfterTestSuite
import com.kms.katalon.core.context.TestCaseContext
import com.kms.katalon.core.context.TestSuiteContext
import java.nio.file.Path
import java.nio.file.Paths
import java.util.Properties.*
import java.lang.String
import com.kms.katalon.core.testdata.reader.ExcelFactory

class ListenerConfig {
	/**
	 * Executes before every test suite starts.
	 * @param testCaseContext related information of the executed test case.
	 */

	@BeforeTestCase
	def beforeTestSuite(TestSuiteContext testSuiteContext) {
		WebUI.comment("*************** Initializing Before TestSuite ***************")
		FileInputStream reader = new FileInputStream('./config.properties');
		Properties properties = new Properties();
		properties.load(reader);
		String environment = properties.getProperty('environment')
		String profile = properties.getProperty('profile')
		GlobalVariable.environment = environment
		GlobalVariable.playerScout = "player@scoutncaa.com"
		GlobalVariable.playerPwd = "FMStelliant444"
		GlobalVariable.emailEurom = "euromcoach2staging@fmsqa.com"
		
		switch (environment) {
			
			case "PROD":
				WebUI.comment("***** Launching URL : " +properties.getProperty('prodURL') + "******");
				GlobalVariable.URL = properties.getProperty('prodURL');
				
			switch (profile) {
				
					case "EUROM":
					WebUI.comment ("## PROFILE is EUROM : PROD ##")
					GlobalVariable.email = "euromcoachprod@fmsqa.com"
					GlobalVariable.emailscout = "euromscoutprod@fmsqa.com"
					break;

					case "NAIAM":
					WebUI.comment ("## PROFILE SELECTED : NAIM ##")
					GlobalVariable.email = "naiamcoachprod@fmsqa.com"
					GlobalVariable.emailscout = "naiamscoutprod@fmsqa.com"
					break;
					
					case "NAIAW":
					WebUI.comment ("## PROFILE SELECTED : NAIAW ##")
					GlobalVariable.email = "naiawcoachprod@fmsqa.com"
					GlobalVariable.emailscout = "naiawscoutprod@fmsqa.com"
					break;
					
					case "NBAG":
					WebUI.comment ("## PROFILE SELECTED : NBAG ##")
					GlobalVariable.email = "nbagcoachprod@fmsqa.com"
					GlobalVariable.emailscout = "nbagscoutprod@fmsqa.com"
					break;
					
					case "NBA":
					WebUI.comment ("## PROFILE SELECTED : NBA ##")
					GlobalVariable.email = "nbacoachprod@fmsqa.com"
					GlobalVariable.emailscout = "nbascoutprod@fmsqa.com"
					break;
					
					case "NCAAB":
					WebUI.comment ("## PROFILE SELECTED : NCAAB ##")
					GlobalVariable.email = "qaautomation1@prod.com"
					GlobalVariable.emailscout = "qaautomation1scout@prod.com"
					break;
					
					case "NCAABII":
					WebUI.comment ("## PROFILE SELECTED : NCAABII ##")
					GlobalVariable.email = "ncaab2coachprod@fmsqa.com"
					GlobalVariable.emailscout = "ncaab2scoutprod@fmsqa.com"
					break;
					
					case "SERIEAM":
					WebUI.comment ("## PROFILE SELECTED : SERIEAM ##")
					GlobalVariable.email = "serieamcoachprod@fmsqa.com"
					GlobalVariable.emailscout = "serieamscoutprod@fmsqa.com"
					break;
					
					case "WNBA":
					WebUI.comment ("## PROFILE SELECTED : WNBA ##")
					GlobalVariable.email = "wnbacoachprod@fmsqa.com"
					GlobalVariable.emailscout = "wnbascoutprod@fmsqa.com"
					break;
					
					case "WNCAAB":
					WebUI.comment ("## PROFILE SELECTED : WNCAAB ##")
					GlobalVariable.email = "wncaabcoachprod@fmsqa.com"
					GlobalVariable.emailscout = "wncaabscoutprod@fmsqa.com"
					break;
					
					case "WNCAABII":
					WebUI.comment ("## PROFILE SELECTED : WNCAABII ##")
					GlobalVariable.email = "wncaab2coachprod@fmsqa.com"
					GlobalVariable.emailscout = "wncaab2scoutprod@fmsqa.com"
					break;
					
					case "FSBASE":
					WebUI.comment ("## PROFILE SELECTED : FSBASE ##")
					GlobalVariable.email = "fsbaseprod@fmsqa.com"
					break;
					
					case "FSPLUS":
					WebUI.comment ("## PROFILE SELECTED : FSPLUS ##")
					GlobalVariable.email = "fsplusprod@fmsqa.com"
					break;
					
					case "FSPREMIER":
					WebUI.comment ("## PROFILE SELECTED : FSPREMIER ##")
					GlobalVariable.email = "fspremierprod@fmsqa.com"
					break;
				}
			
			break;
			
			case "STAGING":
			
				WebUI.comment("***** Launching URL : " +properties.getProperty('stagingURL') + "******");
				GlobalVariable.URL = properties.getProperty('stagingURL');
			break;
			
			case "QA":
			
				WebUI.comment("***** Launching URL : " +properties.getProperty('qaURL') + "******");
				GlobalVariable.URL = properties.getProperty('qaURL');
	
			break;
			
			case "local":
			
				WebUI.comment("***** Launching URL : " +properties.getProperty('localURL') + "******");
				GlobalVariable.URL = properties.getProperty('localURL');
			break;

		}	
		if (environment != "PROD") {
			switch (profile) {
			
					case "EUROM":
					WebUI.comment ("## PROFILE SELECTED : EUROM ##")
					GlobalVariable.email = "euromcoachstaging@fmsqa.com"
					GlobalVariable.emailscout = "euromscoutstaging@fmsqa.com"
					break;
					
					case "NAIAM":
					WebUI.comment ("## PROFILE SELECTED : NAIM ##")
					GlobalVariable.email = "naiamcoachstaging@fmsqa.com"
					GlobalVariable.emailscout = "naiamscoutstaging@fmsqa.com"
					break;
					
					case "NAIAW":
					WebUI.comment ("## PROFILE SELECTED : NAIAW ##")
					GlobalVariable.email = "naiawcoachstaging@fmsqa.com"
					GlobalVariable.emailscout = "naiawscoutstaging@fmsqa.com"
					break;
					
					case "NBAG":
					WebUI.comment ("## PROFILE SELECTED : NBAG ##")
					GlobalVariable.email = "nbagcoachstaging@fmsqa.com"
					GlobalVariable.emailscout = "nbagscoutstaging@fmsqa.com"
					break;
					
					case "NBA":
					WebUI.comment ("## PROFILE SELECTED : NBA ##")
					GlobalVariable.email = "nbacoachstaging@fmsqa.com"
					GlobalVariable.emailscout = "nbascoutstaging@fmsqa.com"
					break;
					
					case "NCAAB":
					WebUI.comment ("## PROFILE SELECTED : NBA ##")
					GlobalVariable.email = "qaautomation1@staging.com"
					GlobalVariable.emailscout = "qaautomation1scout@staging.com"
					break;
					
					case "NCAABII":
					WebUI.comment ("## PROFILE SELECTED : NCAABII ##")
					GlobalVariable.email = "ncaab2coachstaging@fmsqa.com"
					GlobalVariable.emailscout = "ncaab2scoutstaging@fmsqa.com"
					break;
					
					case "SERIEAM":
					WebUI.comment ("## PROFILE SELECTED : SERIEAM ##")
					GlobalVariable.email = "serieamcoachstaging@fmsqa.com"
					GlobalVariable.emailscout = "serieamscoutstaging@fmsqa.com"
					break;
					
					case "WNBA":
					WebUI.comment ("## PROFILE SELECTED : WNBA ##")
					GlobalVariable.email = "wnbacoachstaging@fmsqa.com"
					GlobalVariable.emailscout = "wnbascoutstaging@fmsqa.com"
					break;
					
					case "WNCAAB":
					WebUI.comment ("## PROFILE SELECTED : WNCAAB ##")
					GlobalVariable.email = "qaautomation1@staging.com"
					GlobalVariable.emailscout = "wncaabscoutstaging@fmsqa.com"
					break;
					
					case "WNCAABII":
					WebUI.comment ("## PROFILE SELECTED : WNCAABII ##")
					GlobalVariable.email = "wncaab2coachstaging@fmsqa.com"
					GlobalVariable.emailscout = "wncaab2scoutstaging@fmsqa.com"
					break;
					
					case "default":
					WebUI.comment ("## PROFILE SELECTED : default ##")
					GlobalVariable.email = "qaautomation1@staging.com"
					GlobalVariable.emailscout = "qaautomation1scout@staging.com"
					break;
					
					case "FSBASE":
					WebUI.comment ("## PROFILE SELECTED : FSBASE ##")
					GlobalVariable.email = "fsbasestaging@fmsqa.com"
					break;
					
					case "FSPLUS":
					WebUI.comment ("## PROFILE SELECTED : FSPLUS ##")
					GlobalVariable.email = "fsplusstaging@fmsqa.com"
					break;
					
					case "FSPREMIER":
					WebUI.comment ("## PROFILE SELECTED : FSPREMIER ##")
					GlobalVariable.email = "fspremierstaging@fmsqa.com"
					break;
			}
		}
			
		Object data = ExcelFactory.getExcelDataWithDefaultSheet("Data Files/FastScout_testData.xlsx", profile , true)
		GlobalVariable.data = data
	}

	/**
	 * Executes after every test case ends.
	 * @param testCaseContext related information of the executed test case.
	 */
	@AfterTestCase
	def afterTestCase(TestCaseContext testCaseContext) {
		String testCaseId = testCaseContext.getTestCaseId()
		String testCaseName = testCaseId.substring((testCaseId.lastIndexOf("/").toInteger()) + 1)
		WebUI.comment("###### Completed TestCase:  "+ testCaseName + " : "+testCaseContext.testCaseStatus+ "  #######")
		testCaseContext.getMessage()
	}

	/**
	 * Executes before every test suite starts.
	 * @param testSuiteContext: related information of the executed test suite.
	 */
	//@BeforeTestCase
	def beforeTestCase(TestCaseContext testCaseContext) {
		/*
		 * String testCaseId = testCaseContext.getTestCaseId() String testCaseName =
		 * testCaseId.substring((testCaseId.lastIndexOf("/").toInteger()) + 1)
		 * WebUI.comment("###### Starting TestCase:  "+ testCaseName + "  #######")
		 */	
		}

	/**
	 * Executes after every test suite ends.
	 * @param testSuiteContext: related information of the executed test suite.
	 */
	@AfterTestSuite
	def afterTestSuite(TestSuiteContext testSuiteContext) {
		
	}
}