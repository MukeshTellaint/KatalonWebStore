<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>scheduleTab</name>
   <tag></tag>
   <elementGuidId>ee324a51-69b1-4dcd-9fa1-c7e4deeb1036</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'games-1']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@id = 'games-1']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>games-1</value>
   </webElementProperties>
</WebElementEntity>
