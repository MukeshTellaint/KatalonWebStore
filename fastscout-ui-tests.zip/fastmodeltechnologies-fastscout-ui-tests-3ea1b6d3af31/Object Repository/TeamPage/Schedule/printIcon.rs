<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>printIcon</name>
   <tag></tag>
   <elementGuidId>3bedc4bf-cf08-4366-a4fe-95116498aa54</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'Icons-/-Print']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id = 'Icons-/-Print']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>Icons-/-Print</value>
   </webElementProperties>
</WebElementEntity>
