<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>awayBtn</name>
   <tag></tag>
   <elementGuidId>6a07c64c-91f8-42cf-afb9-a1518b072ebb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'opponent-schedule-AWAY_GAMES']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@id = 'opponent-schedule-AWAY_GAMES']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>opponent-schedule-AWAY_GAMES</value>
   </webElementProperties>
</WebElementEntity>
