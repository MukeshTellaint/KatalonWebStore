<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>last5Btn</name>
   <tag></tag>
   <elementGuidId>c7d9f9e2-2ded-4c5e-91db-b543697cf2ec</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'last-five-2']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Last 5')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>last-five-2</value>
   </webElementProperties>
</WebElementEntity>
