<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>selfScoutsTab</name>
   <tag></tag>
   <elementGuidId>ca18dab7-fd8d-410b-ba43-2b0297ce5707</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'documents-3']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@id = 'documents-3']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>documents-3</value>
   </webElementProperties>
</WebElementEntity>
