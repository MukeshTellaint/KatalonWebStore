<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>pointsPerGameDrpDwn</name>
   <tag></tag>
   <elementGuidId>e6686322-b3f7-452d-91d5-8c1ad10b64ad</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[@name='dropdown-option-name']/following::span[text()='Points Per Game']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
