<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>1playerPerRow</name>
   <tag></tag>
   <elementGuidId>7f850e3c-0627-4246-a711-44dc87a7064e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'players-per-row-2']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[@id = 'players-per-row-1']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>players-per-row-2</value>
   </webElementProperties>
</WebElementEntity>
