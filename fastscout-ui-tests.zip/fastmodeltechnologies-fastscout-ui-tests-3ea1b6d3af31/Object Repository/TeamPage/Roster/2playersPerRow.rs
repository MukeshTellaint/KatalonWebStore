<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>2playersPerRow</name>
   <tag></tag>
   <elementGuidId>91b626a0-a318-47ba-be00-dc857419b66d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'players-per-row-2']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[@id = 'players-per-row-2']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>players-per-row-2</value>
   </webElementProperties>
</WebElementEntity>
