<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>playerFromRoster</name>
   <tag></tag>
   <elementGuidId>e12c2124-1383-409f-b213-cdc6f5fc97ef</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
