<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>rosterTab</name>
   <tag></tag>
   <elementGuidId>bb89c16c-c0ad-4ad9-800c-a43ddbc0267f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'myTeam-2']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@id = 'myTeam-2']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>myTeam-2</value>
   </webElementProperties>
</WebElementEntity>
