<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>selectRankingDrpDwnValue</name>
   <tag></tag>
   <elementGuidId>6de1b60e-06c6-4306-b7a2-55c77bc492ab</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'undefined-option-1']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[@name='dropdown-option-name'][contains(text(),'${rankingDrpDwnVal}')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>undefined-option-1</value>
   </webElementProperties>
</WebElementEntity>
