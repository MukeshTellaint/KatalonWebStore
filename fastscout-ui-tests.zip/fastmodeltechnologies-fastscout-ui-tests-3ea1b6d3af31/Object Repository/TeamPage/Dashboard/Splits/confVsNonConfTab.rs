<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>confVsNonConfTab</name>
   <tag></tag>
   <elementGuidId>abcffe2d-4710-4dc8-8aa0-46c2cb5964a5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'conf-non-conf-5']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>conf-non-conf-5</value>
   </webElementProperties>
</WebElementEntity>
