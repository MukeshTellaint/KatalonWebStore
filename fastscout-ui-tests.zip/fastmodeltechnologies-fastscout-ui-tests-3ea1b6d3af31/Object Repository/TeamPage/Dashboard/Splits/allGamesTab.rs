<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>allGamesTab</name>
   <tag></tag>
   <elementGuidId>3da515e9-e0b1-4160-8399-c587fd5e1161</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//li[contains(@id,'all-')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'all-1']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>all-1</value>
   </webElementProperties>
</WebElementEntity>
