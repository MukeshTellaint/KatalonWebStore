<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>last5Tab</name>
   <tag></tag>
   <elementGuidId>f0cec937-e987-4c36-91b2-dc291686d93b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//li[contains(@id,'last-five')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'last-five-2']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>last-five-2</value>
   </webElementProperties>
</WebElementEntity>
