<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>homeVsAwayTab</name>
   <tag></tag>
   <elementGuidId>34acf2b3-dd70-411c-aac2-56a5a598916a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//li[contains(@id,'home-away')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'home-away-4']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>home-away-4</value>
   </webElementProperties>
</WebElementEntity>
