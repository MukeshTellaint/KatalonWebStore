<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>winsVsLossesTab</name>
   <tag></tag>
   <elementGuidId>d1fe98e1-adf1-4c13-823a-322a77308794</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//li[contains(@id,'win-loss')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'win-loss-3']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>win-loss-3</value>
   </webElementProperties>
</WebElementEntity>
