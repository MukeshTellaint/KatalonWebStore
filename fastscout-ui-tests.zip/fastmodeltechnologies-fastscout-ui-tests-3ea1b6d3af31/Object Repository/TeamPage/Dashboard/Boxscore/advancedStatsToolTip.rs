<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>advancedStatsToolTip</name>
   <tag></tag>
   <elementGuidId>857c759b-0b7d-4afd-beca-ba7175643462</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@col = '+/-']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[contains(text(),'Included in Advanced Stats Package')])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>col</name>
      <type>Main</type>
      <value>+/-</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;advancedBoxscore&quot;]/thead/tr/th[15]/div/div</value>
   </webElementProperties>
</WebElementEntity>
