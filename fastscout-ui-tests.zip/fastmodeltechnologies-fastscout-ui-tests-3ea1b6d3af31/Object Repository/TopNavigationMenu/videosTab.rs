<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>videosTab</name>
   <tag></tag>
   <elementGuidId>b8fcbf58-a07b-4499-a178-55e7fbefcc21</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'videos-nav-link']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@id = 'videos-nav-link']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>videos-nav-link</value>
   </webElementProperties>
</WebElementEntity>
