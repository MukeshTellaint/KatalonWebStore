<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>playsTab</name>
   <tag></tag>
   <elementGuidId>6157d380-788a-4e5e-92bb-3ddf51c93238</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'play-library-nav-link']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@id = 'play-library-nav-link']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>play-library-nav-link</value>
   </webElementProperties>
</WebElementEntity>
