<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>seasonDrpDwnValue</name>
   <tag></tag>
   <elementGuidId>f0622bbb-a229-4a20-ab2b-6bead9b849c9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'season-1']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[contains(@id, 'season-')][contains(text(),'${seasonValue}')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>season-1</value>
   </webElementProperties>
</WebElementEntity>
