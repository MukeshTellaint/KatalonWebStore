<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>myTeamTab</name>
   <tag></tag>
   <elementGuidId>976f7f13-0a2d-461e-b2f3-87542c417f3b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'my-opponents-nav-link']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='my-team-nav-link']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>my-opponents-nav-link</value>
   </webElementProperties>
</WebElementEntity>
