<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Plays sub-tab on PLAYS page</description>
   <name>playBooksTab</name>
   <tag></tag>
   <elementGuidId>4956a7fe-d7f0-4ca2-b672-1da39f6358da</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'plays-0']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@name='playbooks-1']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>plays-0</value>
   </webElementProperties>
</WebElementEntity>
