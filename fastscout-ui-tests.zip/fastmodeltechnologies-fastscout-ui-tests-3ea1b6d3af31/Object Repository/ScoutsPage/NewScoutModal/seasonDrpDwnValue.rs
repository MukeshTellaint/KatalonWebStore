<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>seasonDrpDwnValue</name>
   <tag></tag>
   <elementGuidId>15efa14b-44f2-4817-b5a5-b051cf7fd7c1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'undefined-option-1']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[@name=&quot;dropdown-option-name&quot;][contains(text(),'${seasonYear}')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>undefined-option-1</value>
   </webElementProperties>
</WebElementEntity>
