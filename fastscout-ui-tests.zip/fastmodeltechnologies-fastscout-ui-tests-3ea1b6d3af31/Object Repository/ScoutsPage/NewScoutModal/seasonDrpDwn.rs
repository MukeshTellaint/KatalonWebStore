<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>seasonDrpDwn</name>
   <tag></tag>
   <elementGuidId>406b0052-8f11-4622-b4ba-70118e12a07d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'undefined-dropdown']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[contains(text(),'SEASON')])/following::span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>undefined-dropdown</value>
   </webElementProperties>
</WebElementEntity>
