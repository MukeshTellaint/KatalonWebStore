<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>selectLeague</name>
   <tag></tag>
   <elementGuidId>745cdba1-7687-40ed-a8b4-ed8326965ff2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[text()='${divisionName}']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'undefined-dropdown']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>undefined-dropdown</value>
   </webElementProperties>
</WebElementEntity>
