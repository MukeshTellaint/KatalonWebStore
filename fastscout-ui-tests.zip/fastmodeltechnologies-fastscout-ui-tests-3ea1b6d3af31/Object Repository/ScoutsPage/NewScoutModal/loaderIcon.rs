<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Blank Scouting Report radio button</description>
   <name>loaderIcon</name>
   <tag></tag>
   <elementGuidId>9ecf239a-66b0-4c5d-9a84-ca8cf65323aa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;blankTemplate&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;loader&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;blankTemplate&quot;]</value>
   </webElementProperties>
</WebElementEntity>
