<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>templatesTab</name>
   <tag></tag>
   <elementGuidId>3fa94fdc-adfe-4d0d-8d8c-5aaa431e8aa4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'templates-3']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[contains(@id,'templates')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>templates-3</value>
   </webElementProperties>
</WebElementEntity>
