<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>offlineScoutsTab</name>
   <tag></tag>
   <elementGuidId>4d65560d-70d0-43b0-8699-7d95fa307369</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'offline-2']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[contains(@id,'offline')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>offline-2</value>
   </webElementProperties>
</WebElementEntity>
