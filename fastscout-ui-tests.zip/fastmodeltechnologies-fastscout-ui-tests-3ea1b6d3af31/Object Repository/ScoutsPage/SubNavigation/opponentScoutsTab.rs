<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>opponentScoutsTab</name>
   <tag></tag>
   <elementGuidId>03112f84-2e1a-43a6-b841-0e5cc4f02197</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'opponents-0']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[contains(@id,'opponents')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>opponents-0</value>
   </webElementProperties>
</WebElementEntity>
