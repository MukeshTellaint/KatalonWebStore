<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>ARCHIVED tab on SCOUTS page</description>
   <name>archivedTab</name>
   <tag></tag>
   <elementGuidId>6f2b35fd-0318-4383-9813-cd3c89a5929c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'archived-4']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[contains(@id,'archived')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>archived-4</value>
   </webElementProperties>
</WebElementEntity>
