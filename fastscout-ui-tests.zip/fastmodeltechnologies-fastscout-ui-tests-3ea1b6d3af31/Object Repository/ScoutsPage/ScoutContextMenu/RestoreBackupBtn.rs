<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>restoreBackupBtn</name>
   <tag></tag>
   <elementGuidId>a3259d90-f48f-4037-a45c-f027a656f8cf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'importFromBackup']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[@id = 'importFromBackup']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>importFromBackup</value>
   </webElementProperties>
</WebElementEntity>
