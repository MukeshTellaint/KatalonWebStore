<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Archive button</description>
   <name>duplicateScoutBtn</name>
   <tag></tag>
   <elementGuidId>2d903a6b-9231-4bbf-aa42-0f2bb4df56e1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'duplicate']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>duplicate</value>
   </webElementProperties>
</WebElementEntity>
