<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>updateExistingTemplateChkBox</name>
   <tag></tag>
   <elementGuidId>3114263a-1cdc-4c8f-a3c3-c9c349550a20</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'update-existing-template-option']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>update-existing-template-option</value>
   </webElementProperties>
</WebElementEntity>
