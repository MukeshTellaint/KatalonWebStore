<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>FTShootersSortByFTPerct</name>
   <tag></tag>
   <elementGuidId>1f81c296-ed40-4cd9-8015-c1d37f98e8ec</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'leaders-sort-by-FT%']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>leaders-sort-by-FT%</value>
   </webElementProperties>
</WebElementEntity>
