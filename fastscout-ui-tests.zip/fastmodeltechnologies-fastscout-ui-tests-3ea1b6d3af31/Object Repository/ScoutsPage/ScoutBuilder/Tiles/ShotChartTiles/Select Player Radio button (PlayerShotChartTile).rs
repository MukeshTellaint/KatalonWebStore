<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Select Player Radio button (PlayerShotChartTile)</name>
   <tag></tag>
   <elementGuidId>1f4d0dff-96bd-4d44-8794-5384b38874f3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;appContainer&quot;]/div/div[1]/div/div/div/div/div[2]/div/div/div/div/div[1]/div/div[2]/div[2]/div/div[1]/div[1]/div[2]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;appContainer&quot;]/div/div[1]/div/div/div/div/div[2]/div/div/div/div/div[1]/div/div[2]/div[2]/div/div[1]/div[1]/div[2]/div</value>
   </webElementProperties>
</WebElementEntity>
