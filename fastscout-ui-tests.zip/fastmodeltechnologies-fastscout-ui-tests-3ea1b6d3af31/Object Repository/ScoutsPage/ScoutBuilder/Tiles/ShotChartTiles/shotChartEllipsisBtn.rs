<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>shotChartEllipsisBtn</name>
   <tag></tag>
   <elementGuidId>382fb870-48d5-47f5-bd35-5d2fe0b4a604</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@data-tile-type = 'teamShotChart']//child::div[@id=&quot;tile-ellipsis&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
