<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>shotChartClutchEventsRadioBtn</name>
   <tag></tag>
   <elementGuidId>a4a91f88-ef39-4738-93b4-185f67c08247</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'aggregate-input-1']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>aggregate-input-1</value>
   </webElementProperties>
</WebElementEntity>
