<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>showLastXGamesTxtFld</name>
   <tag></tag>
   <elementGuidId>d47afe8c-509b-412f-a74e-854f0dc62fb2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@name = 'last']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@name = 'last']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>last</value>
   </webElementProperties>
</WebElementEntity>
