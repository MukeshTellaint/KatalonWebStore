<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>clutchStatsTimeRemainingTxtFld</name>
   <tag></tag>
   <elementGuidId>5bf15405-77d5-4d34-8f25-32ef6df1a085</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'timeRemaining']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>timeRemaining</value>
   </webElementProperties>
</WebElementEntity>
