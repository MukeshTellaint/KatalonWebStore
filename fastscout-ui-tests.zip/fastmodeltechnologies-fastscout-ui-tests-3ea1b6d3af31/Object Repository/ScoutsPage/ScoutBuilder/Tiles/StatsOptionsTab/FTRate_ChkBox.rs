<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>FTRate_ChkBox</name>
   <tag></tag>
   <elementGuidId>3c362bf2-1be1-4c4f-9bd9-e8dae8f8fd71</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'checkbox-FTRate-2']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[contains(@id, 'checkbox-FTRate')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>checkbox-FTRate-2</value>
   </webElementProperties>
</WebElementEntity>
