<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>1st game listed on GAMES tab of Individual Boxscore tile</description>
   <name>individualBoxscoreGameChckBox</name>
   <tag></tag>
   <elementGuidId>7e161eb2-5bd3-4c54-abab-e9aef859037e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;input-0&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//*[@id=&quot;input-0&quot;])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;input-0&quot;]</value>
   </webElementProperties>
</WebElementEntity>
