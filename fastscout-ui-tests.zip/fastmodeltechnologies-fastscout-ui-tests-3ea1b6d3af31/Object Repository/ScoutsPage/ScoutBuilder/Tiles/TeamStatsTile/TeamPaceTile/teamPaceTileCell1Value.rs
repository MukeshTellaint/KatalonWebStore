<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>teamPaceTileCell1Value</name>
   <tag></tag>
   <elementGuidId>aaf0f9ec-8fd3-4ed2-b8ad-0003118ce54c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>((//span[contains(text(),'Team Pace')]/../following::div[1])//td[3]/div/div/div)[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>/html/body/div[1]/div/div/div/div[1]/div/div/div/div/div[1]/div[6]/main/div/div/div/div/div/div/div[1]/div[2]/div/div/div/div[2]/div[2]/div/div/div/table/tbody/tr/td[2]/div/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/div[1]/div/div/div/div[1]/div/div/div/div/div[1]/div[6]/main/div/div/div/div/div/div/div[1]/div[2]/div/div/div/div[2]/div[2]/div/div/div/table/tbody/tr/td[2]/div/div/div</value>
   </webElementProperties>
</WebElementEntity>
