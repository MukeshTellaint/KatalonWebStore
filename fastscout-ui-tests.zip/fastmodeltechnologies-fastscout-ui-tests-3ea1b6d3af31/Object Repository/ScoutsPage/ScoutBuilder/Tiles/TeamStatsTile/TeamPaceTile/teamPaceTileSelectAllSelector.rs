<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>selector to select all cells in Team Pace tile</description>
   <name>teamPaceTileSelectAllSelector</name>
   <tag></tag>
   <elementGuidId>b81b5018-9e8b-4a53-b54e-784b608d51eb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/div[1]/div/div/div/div[1]/div/div/div/div/div[1]/div[6]/main/div/div/div/div/div/div/div[1]/div[2]/div/div/div/div[2]/div[2]/div/div/div/table/thead/tr/th[2]/div/div[1]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//span[contains(text(),'Team Pace')]/../following::div[@class=&quot;cursor-pointer position-absolute bg-color-dark-gray-lighten hover-bg-color-header-blue&quot;])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/div[1]/div/div/div/div[1]/div/div/div/div/div[1]/div[6]/main/div/div/div/div/div/div/div[1]/div[2]/div/div/div/div[2]/div[2]/div/div/div/table/thead/tr/th[2]/div/div[1]</value>
   </webElementProperties>
</WebElementEntity>
