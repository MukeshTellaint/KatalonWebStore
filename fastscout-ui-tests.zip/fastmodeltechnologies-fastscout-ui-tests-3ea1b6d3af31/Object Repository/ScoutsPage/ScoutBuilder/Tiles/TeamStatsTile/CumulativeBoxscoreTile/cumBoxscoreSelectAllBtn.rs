<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>cumBoxscoreSelectAllBtn</name>
   <tag></tag>
   <elementGuidId>e46ca190-965d-4033-8d9f-ccbdf8770889</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/div[1]/div/div/div/div[1]/div/div/div/div/div[1]/div[6]/main/div/div/div/div/div/div/div[1]/div[2]/div/div/div/div[2]/div[2]/div/div/div/div/table/thead/tr/th[2]/div/div[1]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//span[contains(text(),'Team Boxscore')]/../following::div[@class=&quot;cursor-pointer position-absolute bg-color-dark-gray-lighten hover-bg-color-header-blue&quot;])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/div[1]/div/div/div/div[1]/div/div/div/div/div[1]/div[6]/main/div/div/div/div/div/div/div[1]/div[2]/div/div/div/div[2]/div[2]/div/div/div/div/table/thead/tr/th[2]/div/div[1]</value>
   </webElementProperties>
</WebElementEntity>
