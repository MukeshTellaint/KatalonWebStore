<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>cumBoxscorePlayerNameCell</name>
   <tag></tag>
   <elementGuidId>8212d414-2068-4044-8836-42ad4a81c621</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//span[contains(text(),'Team Boxscore')]/../following::tr[1]/following::div[8])</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>/html/body/div[1]/div/div/div/div[1]/div/div/div/div/div[1]/div[6]/main/div/div/div/div/div/div/div[1]/div[2]/div/div/div/div[2]/div[2]/div/div/div/div/table/tbody/tr[1]/td[3]/div/div/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/div[1]/div/div/div/div[1]/div/div/div/div/div[1]/div[6]/main/div/div/div/div/div/div/div[1]/div[2]/div/div/div/div[2]/div[2]/div/div/div/div/table/tbody/tr[1]/td[3]/div/div/div/div</value>
   </webElementProperties>
</WebElementEntity>
