<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>FFTileColumn1Selector</name>
   <tag></tag>
   <elementGuidId>75d0a3ac-f11f-4cba-9609-0c125cb5addd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/div[1]/div/div/div/div[1]/div/div/div/div/div[1]/div[6]/main/div/div/div/div/div/div/div[1]/div[2]/div/div/div/div[2]/div[2]/div/div/div/table/thead/tr/th[3]/div/div</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//span[contains(text(),'FastScout Factors')]/../following::div[@class=&quot;cursor-pointer position-absolute bg-color-dark-gray-lighten hover-bg-color-header-blue&quot;])[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/div[1]/div/div/div/div[1]/div/div/div/div/div[1]/div[6]/main/div/div/div/div/div/div/div[1]/div[2]/div/div/div/div[2]/div[2]/div/div/div/table/thead/tr/th[3]/div/div</value>
   </webElementProperties>
</WebElementEntity>
