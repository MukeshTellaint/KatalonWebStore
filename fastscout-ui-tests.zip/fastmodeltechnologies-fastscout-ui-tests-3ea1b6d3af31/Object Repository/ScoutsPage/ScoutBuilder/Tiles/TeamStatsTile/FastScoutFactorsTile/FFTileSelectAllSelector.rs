<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>FFTileSelectAllSelector</name>
   <tag></tag>
   <elementGuidId>826ad2cd-13c1-41bf-a999-ea5a51cf6fb0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/div[1]/div/div/div/div[1]/div/div/div/div/div[1]/div[6]/main/div/div/div/div/div/div/div[1]/div[2]/div/div/div/div[2]/div[2]/div/div/div/table/thead/tr/th[2]/div[2]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//span[contains(text(),'FastScout Factors')]/../following::div[@class=&quot;cursor-pointer position-absolute bg-color-dark-gray-lighten hover-bg-color-header-blue&quot;])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/div[1]/div/div/div/div[1]/div/div/div/div/div[1]/div[6]/main/div/div/div/div/div/div/div[1]/div[2]/div/div/div/div[2]/div[2]/div/div/div/table/thead/tr/th[2]/div[2]</value>
   </webElementProperties>
</WebElementEntity>
