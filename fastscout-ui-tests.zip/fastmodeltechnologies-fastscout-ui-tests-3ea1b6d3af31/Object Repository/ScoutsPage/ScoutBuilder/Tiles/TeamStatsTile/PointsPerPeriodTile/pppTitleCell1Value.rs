<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>pppTitleCell1Value</name>
   <tag></tag>
   <elementGuidId>f7f20074-75ef-4a49-88d7-8201ea9b2d46</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/div[1]/div/div/div/div[1]/div/div/div/div/div[1]/div[6]/main/div/div/div/div/div/div/div[1]/div[2]/div/div/div/div[2]/div[2]/div/div/div/table/tbody/tr[1]/td[2]/div/div/div/div</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>((//span[contains(text(),'Points Per Period')]/../following::div[1])//td[3]/div)[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/div[1]/div/div/div/div[1]/div/div/div/div/div[1]/div[6]/main/div/div/div/div/div/div/div[1]/div[2]/div/div/div/div[2]/div[2]/div/div/div/table/tbody/tr[1]/td[2]/div/div/div/div</value>
   </webElementProperties>
</WebElementEntity>
