<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>teamStatSplitsTileStatColumn1Selector</name>
   <tag></tag>
   <elementGuidId>89506aa3-76d8-4e65-8c49-343f1369485e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/div[1]/div/div/div/div[1]/div/div/div/div/div[1]/div[6]/main/div/div/div/div/div/div/div[1]/div[2]/div/div/div/div[2]/div[2]/div/div/div/div/table/thead/tr/th[3]/div/div</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//span[contains(text(),'Team Stats')]/../following::div[@class=&quot;cursor-pointer position-absolute bg-color-dark-gray-lighten hover-bg-color-header-blue&quot;])[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/div[1]/div/div/div/div[1]/div/div/div/div/div[1]/div[6]/main/div/div/div/div/div/div/div[1]/div[2]/div/div/div/div[2]/div[2]/div/div/div/div/table/thead/tr/th[3]/div/div</value>
   </webElementProperties>
</WebElementEntity>
