<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>last5SplitRadioBtn</name>
   <tag></tag>
   <elementGuidId>c61b4b5c-64a3-430e-8fdf-53cf65992642</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'gamesLast#OfGamesRadioButton']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>gamesLast#OfGamesRadioButton</value>
   </webElementProperties>
</WebElementEntity>
