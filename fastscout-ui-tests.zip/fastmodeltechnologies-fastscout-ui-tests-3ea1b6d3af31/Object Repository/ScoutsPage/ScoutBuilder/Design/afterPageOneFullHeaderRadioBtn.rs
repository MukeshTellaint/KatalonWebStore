<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>afterPageOneFullHeaderRadioBtn</name>
   <tag></tag>
   <elementGuidId>c233aa50-fc1f-44a6-b033-1437cea7779f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'header-size-option-FULL']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>header-size-option-FULL</value>
   </webElementProperties>
</WebElementEntity>
