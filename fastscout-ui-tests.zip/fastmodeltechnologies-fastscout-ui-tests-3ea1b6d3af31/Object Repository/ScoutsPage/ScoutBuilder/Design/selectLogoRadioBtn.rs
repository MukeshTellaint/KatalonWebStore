<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>selectLogoRadioBtn</name>
   <tag></tag>
   <elementGuidId>240b6417-2634-4f5a-bae0-adef2ebfedfe</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'logo-option-MY_TEAM']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(@id,'${logoValue}')]/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>logo-option-MY_TEAM</value>
   </webElementProperties>
</WebElementEntity>
