<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>afterPageOneHideHeaderRadioBtn</name>
   <tag></tag>
   <elementGuidId>a210e065-2f84-489c-a952-2d5111f8b296</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'header-size-option-NONE']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>header-size-option-NONE</value>
   </webElementProperties>
</WebElementEntity>
