<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>playerSearchTxtFld</name>
   <tag></tag>
   <elementGuidId>67734886-f9c2-4334-9b34-90a666067551</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@class = 'Select-placeholder']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class = 'Select-placeholder'][contains(text(),'Player Search')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>Select-placeholder</value>
   </webElementProperties>
</WebElementEntity>
