<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>addPlayer2Btn</name>
   <tag></tag>
   <elementGuidId>ea21460a-8115-4aa2-a388-ba5f3a5868a2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/div[1]/div/div/div/div[1]/div/div/div/div/div/div[1]/div[6]/main/div/div/div/div/div/div[1]/div[1]/div[2]/div/div[4]/div/div[2]/div/div/div/div/a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//a[contains(text(),' Add Player')])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/div[1]/div/div/div/div[1]/div/div/div/div/div/div[1]/div[6]/main/div/div/div/div/div/div[1]/div[1]/div[2]/div/div[4]/div/div[2]/div/div/div/div/a</value>
   </webElementProperties>
</WebElementEntity>
