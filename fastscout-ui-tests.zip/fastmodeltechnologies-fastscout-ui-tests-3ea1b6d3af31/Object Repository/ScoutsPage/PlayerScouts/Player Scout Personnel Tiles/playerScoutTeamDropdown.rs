<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>playerScoutTeamDropdown</name>
   <tag></tag>
   <elementGuidId>f1f2605b-9a90-4cc0-bd30-995fe3e0f7cc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'playerScoutTeamDropdown']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>playerScoutTeamDropdown</value>
   </webElementProperties>
</WebElementEntity>
