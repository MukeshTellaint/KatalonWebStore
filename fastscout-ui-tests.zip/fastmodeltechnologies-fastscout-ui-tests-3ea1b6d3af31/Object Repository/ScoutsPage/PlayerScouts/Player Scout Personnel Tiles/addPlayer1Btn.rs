<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>addPlayer1Btn</name>
   <tag></tag>
   <elementGuidId>4e6a5b54-e5d7-4d79-9fb5-5f8e121da2ab</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/div[1]/div/div/div/div[1]/div/div/div/div/div[1]/div[6]/main/div/div/div/div/div/div[1]/div[1]/div[2]/div/div[3]/div/div[2]/div/div/div/div/a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//a[contains(text(),' Add Player')])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/div[1]/div/div/div/div[1]/div/div/div/div/div[1]/div[6]/main/div/div/div/div/div/div[1]/div[1]/div[2]/div/div[3]/div/div[2]/div/div/div/div/a</value>
   </webElementProperties>
</WebElementEntity>
