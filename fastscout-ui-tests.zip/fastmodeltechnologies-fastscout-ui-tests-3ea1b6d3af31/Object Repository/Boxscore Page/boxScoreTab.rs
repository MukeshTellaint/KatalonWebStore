<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>boxScoreTab</name>
   <tag></tag>
   <elementGuidId>48233d97-d6b8-4a69-98e1-acdee92b1cee</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'summary-1']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@id = 'summary-1']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>summary-1</value>
   </webElementProperties>
</WebElementEntity>
