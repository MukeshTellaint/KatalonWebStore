<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>backToCalendarIcn</name>
   <tag></tag>
   <elementGuidId>370d855f-2f45-44e5-b4bd-c43708436661</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'undefined-0']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@id = 'undefined-0']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>undefined-0</value>
   </webElementProperties>
</WebElementEntity>
