<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>playByPlayTab</name>
   <tag></tag>
   <elementGuidId>fd616f6f-a3b1-4b5a-a4a5-e4eb0bac13cb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'playByPlay-2']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@id = 'playByPlay-2']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>playByPlay-2</value>
   </webElementProperties>
</WebElementEntity>
