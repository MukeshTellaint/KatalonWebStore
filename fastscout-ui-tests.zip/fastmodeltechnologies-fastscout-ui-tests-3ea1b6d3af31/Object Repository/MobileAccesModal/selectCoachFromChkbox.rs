<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>SAVE button in Mobile Access modal</description>
   <name>selectCoachFromChkbox</name>
   <tag></tag>
   <elementGuidId>16ff2d31-a679-4231-9c0e-2108631e622a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'save-report-mobile-access']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[contains(text(),'${coachName}')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>save-report-mobile-access</value>
   </webElementProperties>
</WebElementEntity>
