<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>LeagueDropDwn</name>
   <tag></tag>
   <elementGuidId>aa08d8f5-7754-45be-82e4-56c2f00973c7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//i[@class=&quot;fa fa-caret-down pd-left-sm&quot;])[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
