<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>All Tests</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>edc4b567-7c6c-4cbf-9f35-80db20c09b5d</testSuiteGuid>
   <testCaseLink>
      <guid>9cb563bb-6e63-4ee5-b802-abdcf09c742c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC03_OppScout_BlankTemplate_Add-Edit-DeleteAllTiles1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3bfa94ac-695b-417b-81e8-bc406e02f537</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC04_OppScout_BlankTemplate_Add-Edit-DeleteAllTiles2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7f2af8e6-f36e-4f97-9999-f3de5ac87ba6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC05_Opp Scout_Template1(1 of each tile)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>66a85fa7-7c49-4a49-86f6-eb50bed1fed2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC06_OppScout_Template2(MyTeamPersonnel)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>fd7e449d-b615-4df2-858f-a70f0d0e53e1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC07_OppScout_Template3(Villanova)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>348a0185-49be-4a25-9435-0efb29929341</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC08_OppScoutTemplate3(Villanova)ChangePersonnel</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>844b4609-70cb-4c46-a3e5-c310fa161f05</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC09_OppScoutTemplate4(SIU-Edwardsville)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e6c66189-cee5-4cb7-b6ff-dae241fa3aeb</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC10_OppScout_Template5(Hornets)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>44d2d5a9-2638-4e28-ab39-04f944e26634</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC11_OppScout_Template6(DuluthDII)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>bfbd2aea-3f44-463c-b5d8-bc184edefdf6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC12_OppScoutBlankTemplate_Add-Edit-Del_1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>eabc4e6c-22e2-4160-8bb4-cb2eceef365a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Pages/TC13_BoxscorePage</testCaseId>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>37fe22e7-4fed-4e40-887b-d4b9f3e9bfb1</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>e5a86369-19f3-4ad9-8295-4774554ef082</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Pages/TC14_PlayerPage</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>bbf000c6-2f67-4fbc-becf-bf5dea187d64</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Pages/TC15_HiddenFeatureFlags</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d6d080c9-5dea-443c-b940-e77dafaca1e5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Pages/TC16_TeamPage(Dashboard,Schedule,Roster)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>5e102570-6527-4eb0-bd2d-59e24cc580bc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/PlayerScouts/TC17_NewPlayerScout_SavedTemplate</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a4ca7243-87cb-4fb1-9afa-cb158724ef21</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ScoutBuilder/TC18_BulkStyleTableFormatting</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a41d71d6-6275-42db-b5ea-05f4f0643e65</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ScoutBuilder/TC19_ScoutAttachments</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9241e4e0-0229-45d5-8c2f-66d60d7d2347</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ScoutBuilder/TC20_ScoutBuilderDesign</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0849b7ba-728d-4b0c-9030-47713ddee323</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Self Scouts/TC21_NewSelfScout_Blank Template_AddAllTiles</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>5d704574-b36e-4fe5-808d-3884a2497283</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Self Scouts/TC22_NewSelfScout_Template1(1 of each tile)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7fae209c-e14e-43c6-ace1-3da724894498</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC23_OfflineScout</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>6d4e47d6-a587-4e9c-9de1-ad443c349b50</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC24_Duplicate_OppScout</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>763fddb7-3db4-4283-b727-4cae6892ac63</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/PlayerScouts/TC25_Duplicate_PlayerScout_Template7</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>77ad957a-b789-42b9-bfdf-27dc33014e81</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Consumer/TC26_ConsumerOppScout_Duplicate</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>bd7c30de-5d26-4c70-9143-5b54e791a03e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Self Scouts/TC27_NewSelfScout_Duplicate</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e6f1af31-6dee-4476-aae4-7621050b4f46</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC28_OppScoutSavedTemplate_RestoreBackUp</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>faaa3e35-c7a4-4d71-a894-6bb29de7983d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC29_CrossLeagueWorkflow</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>c9b049e6-215c-4105-8094-57940fa0a8f8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/PlayerScouts/TC30_PlayerRoleOnWeb</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a0f6ac4c-803a-4f1e-9500-1a2415878b94</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Consumer/TC31_ConsumerPlayerScout(Blank)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>65ac3b95-a256-4f18-b209-10931c9afd21</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC32_SynergyStatsTile</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>fb76646c-ffc6-4690-8867-989c6b5dff4f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC33_SaveAttachmentsOnTemplate</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7c53ee91-754e-48f4-8f8f-8003d33b431b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC35_Add tile_Create new page</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>53727b71-663d-473b-b4f8-08167ce8efc5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC36_Duplicating scout with videos</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
