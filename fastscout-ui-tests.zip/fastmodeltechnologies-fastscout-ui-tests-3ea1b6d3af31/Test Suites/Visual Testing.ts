<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Visual Testing</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>7a691008-0f05-4827-b0e6-1ba8f1cdb91b</testSuiteGuid>
   <testCaseLink>
      <guid>db29d2bc-5d09-4dbe-90cf-2c3e36ba6dde</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VisualTesting/VT01_Dashboard_Flow</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>2a3e9a1e-e710-4f75-999d-378cc263d4b7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VisualTesting/VT02_ScheduleFlow</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>610a148c-c201-42aa-986c-3194b3fa6971</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/VisualTesting/VT03_Roster_Flow</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>c3af0359-2203-4df3-b614-17bdc7a67bff</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/VisualTesting/VT00_SampleTestCase</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
