<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Consumer Tests</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>3b74ca66-ed46-44a6-9c01-3b7b462e3f5f</testSuiteGuid>
   <testCaseLink>
      <guid>457079f2-d87a-4920-b2f9-75158c55df1b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Consumer/TC01_ConsumerOppScout(Blank)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>feff745f-8974-4305-a953-5226d17c82ef</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Consumer/TC02_ConsumerOppScout(Template)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9f62ee7e-eae9-4bf2-bd63-07636d661e84</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Consumer/TC26_ConsumerOppScout_Duplicate</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f8eb0eb1-4310-4bfe-bf65-63c7ed3e0094</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Consumer/TC31_ConsumerPlayerScout(Blank)</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
