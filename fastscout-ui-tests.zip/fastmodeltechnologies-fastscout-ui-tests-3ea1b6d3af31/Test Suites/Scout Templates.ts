<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Scout Templates</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>cba84d7f-b296-4c85-9b69-b2eecec59dd8</testSuiteGuid>
   <testCaseLink>
      <guid>ab06a1b2-8343-4767-be20-923cfc1f63d1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC05_Opp Scout_Template1(1 of each tile)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>66159eff-8232-42b3-bf74-15a740299abc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC06_OppScout_Template2(MyTeamPersonnel)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>526c7970-a36d-47f8-8c10-bf8e3f771083</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC07_OppScout_Template3(Villanova)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9c208eaf-bee4-4fdd-98bb-ceb8f10db211</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC09_OppScoutTemplate4(SIU-Edwardsville)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0391815d-8e76-4f46-a637-8477444f8091</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC10_OppScout_Template5(Hornets)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>87fa2e9c-5d9b-49a0-989e-59035fd22364</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/OpponentScouts/TC11_OppScout_Template6(DuluthDII)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e19f1915-7ec2-4a28-bea5-b9a91bf25e22</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/PlayerScouts/TC17_NewPlayerScout_SavedTemplate</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d2015926-3e3d-4c33-9b69-adec3817414e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Self Scouts/TC22_NewSelfScout_Template1(1 of each tile)</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
