package common

import java.awt.image.BufferedImage
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.text.DecimalFormat

import javax.imageio.ImageIO

import org.openqa.selenium.WebDriver as driver

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import ru.yandex.qatools.ashot.AShot
import ru.yandex.qatools.ashot.Screenshot
import ru.yandex.qatools.ashot.comparison.ImageDiff
import ru.yandex.qatools.ashot.comparison.ImageDiffer
import ru.yandex.qatools.ashot.coordinates.WebDriverCoordsProvider
import ru.yandex.qatools.ashot.shooting.ShootingStrategies
import org.openqa.selenium.JavascriptExecutor


class UiCheck {

	/**
	 *
	 * @param driver
	 * @param file
	 * @param timeout
	 * @param dpr Device-Pixel-Ratio
	 * @return
	 */

	static File loadFile(String fileName) {
		Path projectDir = Paths.get(RunConfiguration.getProjectDir())
		Path reportDir = projectDir.resolve('Screenshots')
		Files.createDirectories(reportDir)
		Path pngFile = reportDir.resolve(fileName)
		return pngFile.toFile()
	}

	// get diff%
	static Double diffRatioPercent(ImageDiff diff) {
		boolean hasDiff = diff.hasDiff()
		if (!hasDiff) {
			return 0.0
		}
		int diffSize = diff.getDiffSize()
		int area = diff.getMarkedImage().getWidth() * diff.getMarkedImage().getHeight()
		Double diffRatio = diff.getDiffSize() / area * 100
		return diffRatio
	}

	static BufferedImage takeEntirePageImage(driver, int timeout = 500, float dpr = 2.0f) {
		Screenshot screenshot =
				new AShot().coordsProvider(new WebDriverCoordsProvider())
				.shootingStrategy(
				ShootingStrategies.viewportPasting(
				ShootingStrategies.scaling(dpr), timeout
				)
				)
				.takeScreenshot(driver)
		return screenshot.getImage()
	}

	static void saveEntirePageImage(driver, File file, int timeout = 500, float dpr = 2.0f) {
		BufferedImage image = takeEntirePageImage(driver, timeout, dpr)
		ImageIO.write(image, "PNG", file)
	}

	static compareImages(File original, File mimic, String diffImageName) {
		BufferedImage expectedImage = ImageIO.read(original)
		BufferedImage actualImage   = ImageIO.read(mimic)
		Screenshot expectedScreenshot = new Screenshot(expectedImage)
		Screenshot actualScreenshot = new Screenshot(actualImage)
		ImageDiff diff = new ImageDiffer().makeDiff(expectedScreenshot, actualScreenshot)
		BufferedImage markedImage = diff.getMarkedImage()
		DecimalFormat dformat = new DecimalFormat("##0.00")

		// check how much difference found between the original and the mimic.
		// if diff% exceed the criteria, then mark the test case FAILED
		Double criteriaPercent = 2.0
		Double diffRatioPercent = UiCheck.diffRatioPercent(diff)

		if (diffRatioPercent > criteriaPercent) {
			KeywordUtil.markFailed("diffRatio=${dformat.format(diffRatioPercent)} exceeds criteria=${criteriaPercent}")
		}

		// save the diff image into file
		File diffFile = UiCheck.loadFile(diffImageName)
		ImageIO.write(markedImage, "PNG", diffFile)
		WebUI.comment(">>> Wrote the ImageDiff into: ${diffFile.toString()}")
	}

	static File takeSnap(driver, int timeout = 500 , String filename) {
		float dpr = UiCheck.resolveDPR(driver)
		dpr = 2.0f
		File varName = UiCheck.loadFile(filename)
		saveEntirePageImage(driver, varName, 500, dpr)
		return varName
	}

	static float resolveDPR(driver) {
		JavascriptExecutor js = (JavascriptExecutor)driver
		String value = js.executeScript("return window.devicePixelRatio;")
		return Float.parseFloat(value)
	}
}