package common
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords

import internal.GlobalVariable



import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By

import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty

import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil

import com.kms.katalon.core.webui.exception.WebElementNotFoundException


public class Actions {
	@Keyword
	def signInUser1() {
		WebUI.openBrowser('https://fastscout-staging.fastmodelsports.com/')

		WebUI.setText(findTestObject('SignInPage/emailField'), 'qaautomation1@staging.com')

		WebUI.setEncryptedText(findTestObject('SignInPage/passwordField'), 'YzGUhxdT33ALtOhrSF0KEQ==')

		WebUI.click(findTestObject('SignInPage/signInBtn'))

		WebUI.waitForElementVisible(findTestObject('TopNavigationMenu/scoutsTab'), 60)
	}

	@Keyword
	def signInUser1Local() {
		WebUI.openBrowser('')

		WebUI.navigateToUrl('http://localhost:3000')

		WebUI.setText(findTestObject('SignInPage/emailField'), 'qaautomation1@staging.com')

		WebUI.setEncryptedText(findTestObject('SignInPage/passwordField'), 'YzGUhxdT33ALtOhrSF0KEQ==')

		WebUI.click(findTestObject('SignInPage/signInBtn'))

		WebUI.waitForElementVisible(findTestObject('TopNavigationMenu/scoutsTab'), 60)
	}
	@Keyword
	def signInUserScout() {
		WebUI.openBrowser('')

		WebUI.navigateToUrl('https://fastscout-staging.fastmodelsports.com/')

		WebUI.setText(findTestObject('SignInPage/emailField'), 'autoscout@fastmodelqa.com')

		WebUI.setEncryptedText(findTestObject('SignInPage/passwordField'), 'YzGUhxdT33ALtOhrSF0KEQ==')

		WebUI.click(findTestObject('SignInPage/signInBtn'))

		WebUI.waitForElementVisible(findTestObject('TopNavigationMenu/scoutsTab'), 60)
	}
	@Keyword
	def signInUserScoutLocal() {
		WebUI.openBrowser('')

		WebUI.navigateToUrl('http://localhost:3000')

		WebUI.setText(findTestObject('SignInPage/emailField'), 'autoscout@fastmodelqa.com')

		WebUI.setEncryptedText(findTestObject('SignInPage/passwordField'), 'YzGUhxdT33ALtOhrSF0KEQ==')

		WebUI.click(findTestObject('SignInPage/signInBtn'))

		WebUI.waitForElementVisible(findTestObject('TopNavigationMenu/scoutsTab'), 60)
	}

	@Keyword
	def createOpponentScoutBlankTemplate() {
		WebUI.click(findTestObject('TopNavigationMenu/scoutsTab'))

		WebUI.click(findTestObject('Scouts - Opponent Scouts/NEW SCOUTING REPORT button'))

		WebUI.click(findTestObject('Objects I know I have to replace/Opponent Team dropdown (needs ID update)'))

		WebUI.click(findTestObject('ScoutsPage/NewScoutModal/teamDrpDwnVal'))

		WebUI.click(findTestObject('ScoutsPage/NewScoutModal/blankTemplateChkBox'))

		WebUI.click(findTestObject('ScoutsPage/NewScoutModal/createBtn'))
	}

	@Keyword
	def archiveOpponentScout() {
		WebUI.mouseOver(findTestObject('ScoutsPage/OpponentScouts/oppScoutNameFromGrid'))

		WebUI.click(findTestObject('ScoutsPage/OpponentScouts/scoutContextEllipsisBtn'))

		WebUI.click(findTestObject('ScoutsPage/ScoutContextMenu/archiveBtn'))
	}


	@Keyword
	def deleteScout() {
		WebUI.mouseOver(findTestObject('ScoutsPage/Archived/archivedScouts1stRow'))

		WebUI.click(findTestObject('ScoutsPage/Archived/scoutArchiveEllipsisIcn'))

		WebUI.click(findTestObject('ScoutsPage/Archived/deleteBtn'))

		WebUI.click(findTestObject('Scouts - Archived/Confirm Delete'))
	}


	@Keyword
	def addSectionHeaderTile() {
		WebUI.click(findTestObject('ScoutsPage/ScoutBuilder/Tiles/SectionHeaderTile/sectionHeaderTile'))

		WebUI.click(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

		WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/SectionHeaderTile'))
	}

	@Keyword
	def editSectionHeaderTile() {
		WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/SectionHeaderTile'))

		WebUI.click(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

		WebUI.click(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))
	}

	@Keyword
	def deleteSectionHeaderTile() {
		WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/SectionHeaderTile'))

		WebUI.click(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

		WebUI.click(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))
	}

	@Keyword
	def addFastScoutFactorsTile() {
		WebUI.click(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'))

		WebUI.click(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/FastScoutFactorsTile/fastScoutFactorsTile'))

		WebUI.delay(1)

		WebUI.click(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

		WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/FastScoutFactorsTile'))
	}
}