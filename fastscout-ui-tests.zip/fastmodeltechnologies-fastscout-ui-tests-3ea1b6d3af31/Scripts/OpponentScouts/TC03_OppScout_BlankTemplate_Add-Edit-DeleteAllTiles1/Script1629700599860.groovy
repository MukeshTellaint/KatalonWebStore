import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.common.WebUiCommonHelper as WebUiCommonHelper
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.configuration.RunConfiguration as RunConfiguration


WebUI.openBrowser(GlobalVariable.URL)

WebUI.maximizeWindow()

WebUI.setText(findTestObject('SignInPage/emailField'), GlobalVariable.email)

WebUI.setText(findTestObject('SignInPage/passwordField'), GlobalVariable.password)

WebUI.enhancedClick(findTestObject('SignInPage/signInBtn'))

WebUI.waitForElementVisible(findTestObject('TopNavigationMenu/scoutsTab'), 60)

WebUI.enhancedClick(findTestObject('TopNavigationMenu/scoutsTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/newScoutBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/blankTemplateChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/oppTeamDrpdwn'))

WebUI.delay(5)

WebUI.setText(findTestObject('Object Repository/ScoutsPage/NewScoutModal/oppTeamNameTxtFld'), GlobalVariable.data.getValue(
		'teamName', 3))

WebUI.delay(5)

WebUI.sendKeys(findTestObject('ScoutsPage/NewScoutModal/oppTeamNameTxtFld'), Keys.chord(Keys.ENTER))

WebUI.delay(5)

WebUI.enhancedClick(findTestObject('Object Repository/ScoutsPage/NewScoutModal/seasonDrpDwn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('Object Repository/ScoutsPage/NewScoutModal/seasonDrpDwnValue', [('seasonYear') : GlobalVariable.data.getValue(
				'seasonDrpDwn', 3)]))

WebUI.delay(3)

WebUI.waitForElementClickable(findTestObject('ScoutsPage/NewScoutModal/createBtn'), 30)

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/createBtn'))

WebUI.waitForElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'), 30)

WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/SectionHeaderTile/sectionHeaderTile'), 30)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/SectionHeaderTile/sectionHeaderTile'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/SectionHeaderTile'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/SectionHeaderTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/SectionHeaderTile/sectionHeaderBackgroundColor'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/SectionHeaderTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/SpacerTile/spacerTile'))

WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/SpacerTile'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/SpacerTile'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.verifyElementNotPresent(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/SpacerTile'), 0)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TextTile/textTile'))

WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/TextTile'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/TextTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/addVideos'))

def imgDir = RunConfiguration.getProjectDir() + '/Data Files/Videos/FS Test Video.mp4'

WebUI.uploadFile(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videoUploadInput'), imgDir)

WebUI.delay(2)

WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videoAsset'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/TextTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ImageTile/imageTile'))

WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/ImageTile'))

def imgDir2 = RunConfiguration.getProjectDir() + '/Data Files/Images/FS Test Image.png'

WebUI.uploadFile(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ImageTile/uploadImage'), imgDir2)

WebUI.delay(3)

WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ImageTile/uploadedImage(PresenceOf)'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/ImageTile'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/ImageTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.delay(3)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/FastScoutFactorsTile/fastScoutFactorsTile'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/statsTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.delay(1)

WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/FastScoutFactorsTile'))

WebUI.delay(1)

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/FastScoutFactorsTile'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/optionsTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/statsTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/optionsTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/leagueRankingsRadioBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/statsTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/FTRate_ChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/AST Perct_ChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/FastScoutFactorsTile'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/FastScoutFactorsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/FastScoutFactorsChartTile/fastScoutFactorsChartTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/FastScoutFactorsChartTile'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/FastScoutFactorsChartTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/optionsTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/GamesTab/homeSplitRadioBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/optionsTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/FastScoutFactorsChartTile/FFChartSelectStatDrpDwn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/FastScoutFactorsChartTile/FFChartSelectStatDrpDwnValue',
		[('ffChartDrpDwnValue') : 'True Shooting %']))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/FastScoutFactorsChartTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/PointsPerPeriodTile/pointsPerPeriodTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/PointsPerPeriodTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/sampleTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/teamDrpDwnInTileEditor'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/selectTeamFrmDrpdwnInTileEditor'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/PointsPerPeriodTile/pppOvertimeChckBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/PointsPerPeriodTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.delay(1)

WebUI.verifyElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'))

WebUI.delay(1)

WebUI.verifyElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamPaceTile/teamPaceTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamPaceTile/teamPaceTile'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/TeamPaceTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/GamesTab/homeSplitRadioBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/optionsTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/leagueRankingsRadioBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/TeamPaceTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamPaceChartTile/teamPaceChartTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/TeamPaceChartTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/GamesTab/homeSplitRadioBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/optionsTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamPaceChartTile/opponentConferenceChckBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/TeamPaceChartTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/IndividualBoxscoreTile/individualBoxscoreTile'))

WebUI.enhancedClick(findTestObject('Object Repository/ScoutsPage/ScoutBuilder/Tiles/tileSeasonDrpDwn'))

WebUI.enhancedClick(findTestObject('Object Repository/ScoutsPage/ScoutBuilder/Tiles/tileSeasonDrpDwnValue', [('seasonDrpDwn') : GlobalVariable.data.getValue(
				'seasonDrpDwn', 9)]))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/IndividualBoxscoreTile/individualBoxscoreGameChckBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/optionsTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/IndividualBoxscoreTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/optionsTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/USGPerct_ChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/Plus-Minus_ChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/REB_ChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/customStatTxtFld'))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/customStatTxtFld'), 'myStat')

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/customStatAddBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/IndividualBoxscoreTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/CumulativeBoxscoreTile/cumulativeBoxscoreTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/playersTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/sampleTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/CumulativeBoxscoreTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

//Need to add calendar dropdown
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/GamesTab/firstListedGameChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/statsTab'))

if (true) {
	WebUI.click(findTestObject(null))
}

if (GlobalVariable.profile.is('FSBASE') == false) {
	//Not applicable for FSBase profile
	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/eFG Perct_ChkBox'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/STL_ChkBox'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/3P-R_ChkBox'))

	//Not applicable for FSBase profile
	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/USGPerct_ChkBox'))

	//Not applicable for FSBase profile
	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/per40StatTypeRadioBtn'))
}

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/FTM-A_ChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/customStatTxtFld'))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/customStatTxtFld'), 'myStat')

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/customStatAddBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/PTS Column Order'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/playersTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/PersonnelTiles/personnelPlayer1'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/sampleTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/CumulativeBoxscoreTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamStatComparisonTile/teamStatComparisonTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

if (GlobalVariable.profile != 'FSBASE') {
	WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/TeamStatComparisonTile'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/sampleTab'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/addVideoBtn'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/fromSynergyBtn'))

	WebUI.setText(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/synergyUsernameTxtFld'), 'sachin@fastmodeltechnologies.com')

	WebUI.setEncryptedText(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/synergyPasswordTxtFld'), 'YzGUhxdT33BEbO8XdJTy9g==')

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/synergyLoginBtn'))

	WebUI.delay(5)

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/synergyClipSearchTxtFld'))

	WebUI.setText(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/synergyClipSearchTxtFld'), 'Toronto')

	WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/firstSynergyTitleSelect'), 10)

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/firstSynergyTitleSelect'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/firstSynergyClipChkBox'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/addClipsDoneBtn'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/addClipsBtnInSynergyEditModal'))

	WebUI.delay(2)

	WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/synergyVideoPresence'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))
}

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/TeamStatComparisonTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamStatSplitsTile/teamStatSplitsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/sampleTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/TeamStatSplitsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamStatSplitsTile/offensiveSplitAllGamesChckBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamStatSplitsTile/defensiveSplitAllGamesChckBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/GamesTab/CustomSplit(Personnel,TeamStatSplits)/addCustomSplitBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/GamesTab/CustomSplit(Personnel,TeamStatSplits)/allGamesFilterBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/GamesTab/CustomSplit(Personnel,TeamStatSplits)/splitNameTxtFld'))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/GamesTab/CustomSplit(Personnel,TeamStatSplits)/splitNameTxtFld'),
	'MySplit')

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/GamesTab/CustomSplit(Personnel,TeamStatSplits)/newCustomSplitAddBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/statsTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/PTS_ChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/PACE(TeamStatSplits)_ChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/customStatTxtFld'))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/customStatTxtFld'), 'myStat')

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/customStatAddBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/wholeNumbersChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/sampleTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/TeamStatSplitsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

if (GlobalVariable.profile != 'FSBASE') {
	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamAdvancedStatsTile/teamAdvancedStatsTile'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

	WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/TeamAdvancedStatsTile'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

	WebUI.delay(1)

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/optionsTab'))

	WebUI.delay(1)

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/PW_ChkBox'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/PL_ChkBox'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/leagueRankingsRadioBtn'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

	WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/TeamAdvancedStatsTile'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))
}

if (GlobalVariable.profile == 'FSBASE') {
	WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ClutchStatsTile/clutchStatsTile'))

	WebUI.delay(4)

	WebUI.verifyElementPresent(findTestObject('Object Repository/ScoutsPage/ScoutBuilder/Tiles/includedInAdvancedStatsTxt'),
		10)
} else {
	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ClutchStatsTile/clutchStatsTile'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/playersTab'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/sampleTab'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

	WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/ClutchStatsTile'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ClutchStatsTile/clutchStatsTimeRemainingTxtFld'))

	WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ClutchStatsTile/clutchStatsTimeRemainingTxtFld'), Keys.chord(
			Keys.BACK_SPACE))

	WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ClutchStatsTile/clutchStatsTimeRemainingTxtFld'), '3')

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ClutchStatsTile/clutchStatsScoreWithinTxtFld'))

	WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ClutchStatsTile/clutchStatsScoreWithinTxtFld'), Keys.chord(
			Keys.BACK_SPACE))

	WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ClutchStatsTile/clutchStatsScoreWithinTxtFld'), '3')

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/customStatTxtFld'))

	WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/customStatTxtFld'), 'myStat')

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/customStatAddBtn'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/playersTab'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/PersonnelTiles/personnelPlayer1'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/sampleTab'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

	WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/ClutchStatsTile'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

	WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))
}

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/TopMenu/doneBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/OpponentScouts/oppScoutNameFromGrid', [('scoutName') : GlobalVariable.data.getValue(
				'teamName', 3)]))

WebUI.enhancedClick(findTestObject('ScoutsPage/OpponentScouts/scoutContextEllipsisBtn', [('scoutName') : GlobalVariable.data.getValue(
				'teamName', 3)]))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutContextMenu/archiveBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/SubNavigation/archivedTab'))

WebUI.mouseOver(findTestObject('ScoutsPage/Archived/archivedScouts1stRow'))

WebUI.enhancedClick(findTestObject('ScoutsPage/Archived/scoutArchiveEllipsisIcn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/Archived/deleteBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/Archived/confirmDeleteScoutBtn'))

WebUI.closeBrowser()
