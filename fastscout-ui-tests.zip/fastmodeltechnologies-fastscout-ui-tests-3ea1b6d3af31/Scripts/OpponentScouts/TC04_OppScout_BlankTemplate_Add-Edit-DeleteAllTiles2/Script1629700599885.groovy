import  static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import  static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import  static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import  static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import  static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.common.WebUiCommonHelper as WebUiCommonHelper
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.Keys as Keys


WebUI.openBrowser(GlobalVariable.URL)
WebUI.maximizeWindow()
WebUI.setText(findTestObject('SignInPage/emailField'), GlobalVariable.email)
WebUI.setText(findTestObject('SignInPage/passwordField'), GlobalVariable.password)

WebUI.enhancedClick(findTestObject('SignInPage/signInBtn'))

WebUI.waitForElementVisible(findTestObject('TopNavigationMenu/scoutsTab'), 60)
WebUI.enhancedClick(findTestObject('TopNavigationMenu/scoutsTab'))

WebUI.waitForElementClickable(findTestObject('ScoutsPage/NewScoutModal/newScoutBtn'), 0)

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/newScoutBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/blankTemplateChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/oppTeamDrpdwn'))
WebUI.delay(15)
WebUI.setText(findTestObject('Object Repository/ScoutsPage/NewScoutModal/oppTeamNameTxtFld'),(GlobalVariable.data).getValue("teamName", 10))
WebUI.delay(5)
WebUI.sendKeys(findTestObject('ScoutsPage/NewScoutModal/oppTeamNameTxtFld'), Keys.chord(Keys.ENTER))
WebUI.delay(3)

WebUI.enhancedClick(findTestObject('Object Repository/ScoutsPage/NewScoutModal/seasonDrpDwn'))

WebUI.enhancedClick(findTestObject('Object Repository/ScoutsPage/NewScoutModal/seasonDrpDwnValue', [('seasonYear') : (GlobalVariable.data).getValue("seasonDrpDwn", 10)]))

WebUI.delay(15)

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/createBtn'))

WebUI.waitForElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LineupStatsTile/lineupStatsTile'), 15)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LineupStatsTile/lineupStatsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/playersTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/LineupStatsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/playersTab'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LineupStatsTile/lineupSizeRadioBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/optionsTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/TOPerct_ChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/pace_ChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/customStatTxtFld'))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/customStatTxtFld'), 'myStat')

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/customStatAddBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LineupStatsTile/lineupStatsMinimumMinsTxtFld'))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LineupStatsTile/lineupStatsMinimumMinsTxtFld'), Keys.chord(Keys.BACK_SPACE))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LineupStatsTile/lineupStatsMinimumMinsTxtFld'), '30')

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LineupStatsTile/lineupStatsLineupsDisplayedTxtFld'))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LineupStatsTile/lineupStatsLineupsDisplayedTxtFld'), Keys.chord(Keys.BACK_SPACE))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LineupStatsTile/lineupStatsLineupsDisplayedTxtFld'), Keys.chord(Keys.BACK_SPACE))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LineupStatsTile/lineupStatsLineupsDisplayedTxtFld'), '5')

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/playersTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.delay(1)

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/LineupStatsTile'))
WebUI.scrollToElement(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'),10)
WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/PersonnelTiles/Tiles Menu_Personnel'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/PersonnelTiles/personnelPlayer1'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/statsTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/PersonnelTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/PersonnelTiles/personnelHomeSplit'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/statsTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/USGPerct_ChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/REB_ChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/customStatTxtFld'))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/customStatTxtFld'), 'myStat')

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/customStatAddBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/addVideoBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/fromSynergyBtn'))

WebUI.setText(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/synergyUsernameTxtFld'), 'sachin@fastmodeltechnologies.com')

WebUI.setEncryptedText(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/synergyPasswordTxtFld'), 'YzGUhxdT33BEbO8XdJTy9g==')

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/synergyLoginBtn'))

WebUI.delay(5)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/synergyClipSearchTxtFld'))

WebUI.setText(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/synergyClipSearchTxtFld'), 'Toronto')

WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/firstSynergyTitleSelect'),15)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/firstSynergyTitleSelect'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/firstSynergyClipChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/addClipsDoneBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/addClipsBtnInSynergyEditModal'))

WebUI.delay(2)

WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/synergyVideoPresence'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/PersonnelTile'))
WebUI.scrollToElement(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'),10)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))
WebUI.waitForElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/tilesMenuLeaders'),15)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/tilesMenuLeaders'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/TopScorersTile/topScorersTile'))

WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'), 15)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/LeaderTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/TopScorersTile/minimumFGAField'))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/TopScorersTile/minimumFGAField'),'5')

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/LeaderTile'))
WebUI.scrollToElement(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'),10)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/tilesMenuLeaders'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/3PointShootersTile/3PointShootersTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.waitForElementPresent(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/LeaderTile'),30)
WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/LeaderTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/minimumLeaderRows'))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/minimumLeaderRows'), Keys.chord(Keys.BACK_SPACE))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/minimumLeaderRows'), '3')

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/3PM-A Column Order'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/3PointShootersTile/minimum3PAField'))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/3PointShootersTile/minimum3PAField'),
	'5')

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/3PointShootersTile/3P-R_ChckBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/LeaderTile'))
WebUI.scrollToElement(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'),10)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/tilesMenuLeaders'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/FTShootersTile/FTShootersTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/LeaderTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/FTShootersTile/minimumFTAField'))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/FTShootersTile/minimumFTAField'),
	'2')

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/FTShootersTile/FTShootersSortByFTPerct'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/FTShootersTile/FTShootersSortByFTPerct'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/LeaderTile'))

WebUI.delay(1)
WebUI.scrollToElement(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'),10)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))
WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/tilesMenuLeaders'),15)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/tilesMenuLeaders'))
WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/Rebounds/reboundsTile'), 15)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/Rebounds/reboundsTile'))
WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'), 15)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))
WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'), 10)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/LeaderTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.delay(1)
WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'), 10)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/GamesTab/last5SplitRadioBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/LeaderTile'))
WebUI.scrollToElement(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'),10)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/tilesMenuLeaders'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/BallControlTile/ballControlTile'))

WebUI.delay(1)
WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'),10)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/LeaderTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/per40StatTypeRadioBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/LeaderTile'))
WebUI.scrollToElement(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'),10)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/tilesMenuLeaders'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/DefenseTile/defenseTile'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.delay(1)

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/LeaderTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/DefenseTile/BLKColumnHeader'))

WebUI.delay(1)

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/LeaderTile'))

WebUI.delay(1)
WebUI.scrollToElement(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'),10)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/RecentGamesTile/recentGamesTile'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.delay(1)

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/RecentGamesTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/RecentGamesTile/showLastXGamesTxtFld'))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/RecentGamesTile/showLastXGamesTxtFld'), Keys.chord(
		Keys.BACK_SPACE))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/RecentGamesTile/showLastXGamesTxtFld'), '8')

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/RecentGamesTile/recentGamesDateChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/RecentGamesTile'))
WebUI.scrollToElement(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'),10)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/DepthChartTile/depthChartTile'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/DepthChartTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/DepthChartTile/firstNameChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/DepthChartTile/firstInitialChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/DepthChartTile'))
WebUI.scrollToElement(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'),10)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/CustomTableTile/customTableTile'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/CustomTableTile/2x2InTileBuilder'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/CustomTableTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ShotChartTiles/shotChartsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ShotChartTiles/offensiveTeamShotChartTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.delay(3)

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/OffenseTeamShotChartTile'))

WebUI.enhancedClick(findTestObject('Object Repository/ScoutsPage/ScoutBuilder/Tiles/ShotChartTiles/shotChartEllipsisBtn'))
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ShotChartTiles/zoneShotChartTypeRadioBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ShotChartTiles/shotChartShowFGPercntChkBox'))
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))
WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/OffenseTeamShotChartTile'))
WebUI.waitForElementVisible(findTestObject('Object Repository/ScoutsPage/ScoutBuilder/Tiles/ShotChartTiles/shotChartEllipsisBtn'),10)
WebUI.waitForElementClickable(findTestObject('Object Repository/ScoutsPage/ScoutBuilder/Tiles/ShotChartTiles/shotChartEllipsisBtn'),10)
//WebUI.scrollToElement(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'),10)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))
WebUI.waitForElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'),10)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))
WebUI.delay(5)
//WebUI.verifyElementNotPresent(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/OffenseTeamShotChartTile'),20)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ShotChartTiles/shotChartsTile'))
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ShotChartTiles/defensiveTeamShotChartTile'))
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.delay(3)

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/DefenseTeamShotChartTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ShotChartTiles/zoneShotChartTypeRadioBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ShotChartTiles/shotChartShowFGPercntChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/DefenseTeamShotChartTile'))
WebUI.scrollToElement(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'),10)
WebUI.waitForElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'),10)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))
WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'),10)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ShotChartTiles/shotChartsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ShotChartTiles/playerChartTile'))

WebUI.waitForElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ShotChartTiles/playerChartPlayer1RadioBtn'),20)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ShotChartTiles/playerChartPlayer1RadioBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.delay(2)

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/PlayerShotChartTile'))
WebUI.waitForElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'),15)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.waitForElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ShotChartTiles/playerChartPlayer2RadioBtn'),20)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ShotChartTiles/playerChartPlayer2RadioBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ShotChartTiles/makeMissShotChartTypeRadioBtn'))

//clutch shot chart code below
/*
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ShotChartTiles/shotChartClutchEventsRadioBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ClutchStatsTile/clutchStatsTimeRemainingTxtFld'))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ClutchStatsTile/clutchStatsTimeRemainingTxtFld'), Keys.chord(Keys.BACK_SPACE))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ClutchStatsTile/clutchStatsTimeRemainingTxtFld'), '3')

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ClutchStatsTile/clutchStatsScoreWithinTxtFld'))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ClutchStatsTile/clutchStatsScoreWithinTxtFld'), Keys.chord(Keys.BACK_SPACE))

WebUI.sendKeys(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ClutchStatsTile/clutchStatsScoreWithinTxtFld'), '3')

*/
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/gamesTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/GamesTab/last5SplitRadioBtn'))

//WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videosTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/PlayerShotChartTile'))
WebUI.scrollToElement(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'),10)
WebUI.waitForElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'),10)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.waitForElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'),10)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/PlaysTiles/PlaysTile'))

WebUI.delay(3)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/PlaysTiles/selectPlaysTile1ChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/PlayTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/PlaysTiles/selectPlaysTile2ChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/PlayTile'))
WebUI.scrollToElement(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'), 10)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/TopMenu/doneBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/OpponentScouts/oppScoutNameFromGrid', [('scoutName') : (GlobalVariable.data).getValue("teamName", 10)]))

WebUI.enhancedClick(findTestObject('ScoutsPage/OpponentScouts/scoutContextEllipsisBtn', [('scoutName') : (GlobalVariable.data).getValue("teamName", 10)]))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutContextMenu/archiveBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/SubNavigation/archivedTab'))

WebUI.mouseOver(findTestObject('ScoutsPage/Archived/archivedScouts1stRow'))

WebUI.enhancedClick(findTestObject('ScoutsPage/Archived/scoutArchiveEllipsisIcn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/Archived/deleteBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/Archived/confirmDeleteScoutBtn'))

WebUI.closeBrowser()
