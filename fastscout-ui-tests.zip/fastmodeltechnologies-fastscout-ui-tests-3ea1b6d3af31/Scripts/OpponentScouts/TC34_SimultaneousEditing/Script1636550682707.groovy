import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.Dimension as Dimension
import org.openqa.selenium.Point as Point
import org.openqa.selenium.chrome.ChromeDriver as ChromeDriver
import org.openqa.selenium.chrome.ChromeOptions as ChromeOptions
import com.kms.katalon.core.testobject.ConditionType as ConditionType
import com.kms.katalon.core.configuration.RunConfiguration as RunConfiguration

/**
 * opens a Chrome browser with nothing special
 * returns the ChromeDriver instance that is assocated with the window
 * @return
 */
ChromeDriver openChromeBrowserPlain() {
	return openChromeBrowser(new ChromeOptions())
}
/**
 * opens a Chrome browser with -incoginito mode,
 * returns the ChromeDriver instance that is associated with the window
 */
ChromeDriver openChromeBrowserInIncognitoMode() {
	ChromeOptions options = new ChromeOptions()
	options.addArguments("–incognito")
	return openChromeBrowser(options);
}

/**
 * opens a ChromeBrowser with the ChromeOptions given.
 * returns the ChromeDriver instance that is associated with the window
 * @param options
 * @return
 */
ChromeDriver openChromeBrowser(ChromeOptions options) {
	System.setProperty("webdriver.chrome.driver", DriverFactory.getChromeDriverPath())
	return new ChromeDriver(options);
}

/**
 * resize the browser window to horizontal half, and move it to the right side
 * @param driver
 * @returns Dimension of the window
 */
Dimension resizeHorizontalHalfLocateLeft(WebDriver driver) {
	Dimension d = resizeToHorizontalHalf(driver)
	driver.manage().window().setPosition(new Point(0, 0));
	return d
}

/**
 * resize the browser window to horizontal half, and move it to the left side
 * 
 * @param driver
 * @returns Dimension of the window
 */
Dimension resizeHorizontalHalfLocateRight(WebDriver driver) {
	Dimension d = resizeToHorizontalHalf(driver)
	driver.manage().window().setPosition(new Point(d.getWidth(), 0))
	return d
}

/**
 * resize the browser window to half-width tile;
 * width=half of full screen, height=height of full screen
 * 
 * @param driver
 * @return
 */
Dimension resizeToHorizontalHalf(WebDriver driver) {
	driver.manage().window().maximize()
	Dimension maxDim = driver.manage().window().getSize()
	Dimension curDim = new Dimension((Integer)(maxDim.getWidth() / 2), maxDim.getHeight())
	driver.manage().window().setSize(curDim)
	return curDim
}

//Normal Chrome window
WebDriver normalChrome = openChromeBrowserPlain()

resizeHorizontalHalfLocateLeft(normalChrome)

DriverFactory.changeWebDriver(normalChrome)

WebUI.navigateToUrl(GlobalVariable.URL)

WebUI.waitForPageLoad(10)

//Incognito Chrome window
WebDriver incognitoChrome = openChromeBrowserInIncognitoMode()

resizeHorizontalHalfLocateRight(incognitoChrome)

DriverFactory.changeWebDriver(incognitoChrome)

WebUI.navigateToUrl(GlobalVariable.URL)

WebUI.waitForPageLoad(10)

//Normal Chrome window
DriverFactory.changeWebDriver(normalChrome)

WebUI.comment("switched to ${WebUI.getUrl()}")

WebUI.setText(findTestObject('SignInPage/emailField'), GlobalVariable.email)

WebUI.setText(findTestObject('SignInPage/passwordField'), GlobalVariable.password)

WebUI.enhancedClick(findTestObject('SignInPage/signInBtn'))

WebUI.waitForElementVisible(findTestObject('TopNavigationMenu/scoutsTab'), 60)

WebUI.enhancedClick(findTestObject('TopNavigationMenu/scoutsTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/newScoutBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/blankTemplateChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/oppTeamDrpdwn'))

WebUI.delay(3)

WebUI.setText(findTestObject('Object Repository/ScoutsPage/NewScoutModal/oppTeamNameTxtFld'), GlobalVariable.data.getValue(
        'teamName', 40))

WebUI.delay(3)

WebUI.sendKeys(findTestObject('ScoutsPage/NewScoutModal/oppTeamNameTxtFld'), Keys.chord(Keys.ENTER))

WebUI.delay(5)

WebUI.enhancedClick(findTestObject('Object Repository/ScoutsPage/NewScoutModal/seasonDrpDwn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('Object Repository/ScoutsPage/NewScoutModal/seasonDrpDwnValue', [('seasonYear') : GlobalVariable.data.getValue(
                'seasonDrpDwn', 40)]))

WebUI.delay(3)

WebUI.waitForElementClickable(findTestObject('ScoutsPage/NewScoutModal/createBtn'), 30)

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/createBtn'))

WebUI.delay(3)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/FastScoutFactorsTile/fastScoutFactorsTile'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.delay(1)

WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/FastScoutFactorsTile'))

WebUI.delay(1)

//Incoginto Chrome window
DriverFactory.changeWebDriver(incognitoChrome)

WebUI.comment("switched to ${WebUI.getUrl()}")

WebUI.setText(findTestObject('SignInPage/emailField'), GlobalVariable.emailEurom)

WebUI.setText(findTestObject('SignInPage/passwordField'), GlobalVariable.password)

WebUI.enhancedClick(findTestObject('SignInPage/signInBtn'))

WebUI.waitForElementVisible(findTestObject('TopNavigationMenu/scoutsTab'), 60)

WebUI.enhancedClick(findTestObject('TopNavigationMenu/scoutsTab'))

WebUI.mouseOver(findTestObject('ScoutsPage/OpponentScouts/oppScoutNameFromGrid', [('scoutName') : GlobalVariable.data.getValue(
                'teamName', 40)]))

WebUI.enhancedClick(findTestObject('ScoutsPage/OpponentScouts/oppScoutNameFromGrid', [('scoutName') : GlobalVariable.data.getValue(
                'teamName', 40)]))

WebUI.delay(1)

WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/FastScoutFactorsTile'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/FastScoutFactorsTile'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileSettings'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/statsTab'))

WebUI.delay(1)

//Normal Chrome window
DriverFactory.changeWebDriver(normalChrome)

WebUI.comment("switched to ${WebUI.getUrl()}")

WebUI.delay(1)

WebUI.verifyElementPresent(findTestObject('ScoutsPage/OpponentScouts/SimultaneuosEditing/highlightCoachEditTxt'),5)

WebUI.delay(1)


//Incoginto Chrome window
DriverFactory.changeWebDriver(incognitoChrome)

WebUI.comment("switched to ${WebUI.getUrl()}")

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/FTRate_ChkBox'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/FastScoutFactorsTile'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/TopMenu/doneBtn'))

//Normal Chrome window
DriverFactory.changeWebDriver(normalChrome)

WebUI.comment("switched to ${WebUI.getUrl()}")

WebUI.delay(1)

WebUI.verifyElementNotPresent(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/FastScoutFactorsTile'),5)

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/TopMenu/doneBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/OpponentScouts/oppScoutNameFromGrid', [('scoutName') : GlobalVariable.data.getValue(
				'teamName', 40)]))

WebUI.enhancedClick(findTestObject('ScoutsPage/OpponentScouts/scoutContextEllipsisBtn', [('scoutName') : GlobalVariable.data.getValue(
				'teamName', 40)]))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutContextMenu/archiveBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/SubNavigation/archivedTab'))

WebUI.mouseOver(findTestObject('ScoutsPage/Archived/archivedScouts1stRow'))

WebUI.enhancedClick(findTestObject('ScoutsPage/Archived/scoutArchiveEllipsisIcn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/Archived/deleteBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/Archived/confirmDeleteScoutBtn'))


// close 2 browser windows
DriverFactory.changeWebDriver(normalChrome)

WebUI.closeBrowser()

WebUI.delay(1)

DriverFactory.changeWebDriver(incognitoChrome)

WebUI.closeBrowser()

