import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.common.WebUiCommonHelper as WebUiCommonHelper
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser(GlobalVariable.URL)

WebUI.setText(findTestObject('SignInPage/emailField'), GlobalVariable.email)

WebUI.setText(findTestObject('SignInPage/passwordField'), GlobalVariable.password)

WebUI.enhancedClick(findTestObject('SignInPage/signInBtn'))

WebUI.waitForElementVisible(findTestObject('TopNavigationMenu/scoutsTab'), 60)

WebUI.enhancedClick(findTestObject('TopNavigationMenu/scoutsTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/newScoutBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/oppTeamDrpdwn'))
WebUI.delay(3)
WebUI.setText(findTestObject('Object Repository/ScoutsPage/NewScoutModal/oppTeamNameTxtFld'),(GlobalVariable.data).getValue("teamName", 24))
WebUI.delay(5)
WebUI.sendKeys(findTestObject('ScoutsPage/NewScoutModal/oppTeamNameTxtFld'), Keys.chord(Keys.ENTER))
WebUI.delay(3)
WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/savedTemplateDrpDwn'))

WebUI.sendKeys(findTestObject('ScoutsPage/NewScoutModal/savedTemplateDrpDwnValue'), '2')

WebUI.sendKeys(findTestObject('ScoutsPage/NewScoutModal/savedTemplateDrpDwnValue'), Keys.chord(Keys.ENTER))

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/createBtn'))

WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/TopMenu/doneBtn'))

WebUI.mouseOver(findTestObject('ScoutsPage/OpponentScouts/oppScoutNameFromGrid', [('scoutName') : (GlobalVariable.data).getValue("teamName", 24)]))

WebUI.enhancedClick(findTestObject('ScoutsPage/OpponentScouts/scoutContextEllipsisBtn', [('scoutName') : (GlobalVariable.data).getValue("teamName", 24)]))

WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutContextMenu/archiveBtn'), 0)

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutContextMenu/archiveBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutContextMenu/archiveBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/SubNavigation/archivedTab'))

WebUI.mouseOver(findTestObject('ScoutsPage/Archived/archivedScouts1stRow'))

WebUI.enhancedClick(findTestObject('ScoutsPage/Archived/scoutArchiveEllipsisIcn'))

WebUI.waitForElementClickable(findTestObject('ScoutsPage/Archived/deleteBtn'), 0)

WebUI.mouseOver(findTestObject('ScoutsPage/Archived/deleteBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/Archived/deleteBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/Archived/confirmDeleteScoutBtn'))

WebUI.closeBrowser()

