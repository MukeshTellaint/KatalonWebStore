import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.common.WebUiCommonHelper as WebUiCommonHelper
import org.openqa.selenium.WebElement as WebElement
import com.kms.katalon.core.configuration.RunConfiguration as RunConfiguration

WebUI.comment(GlobalVariable.environment)
WebUI.openBrowser(GlobalVariable.URL)

if (GlobalVariable.environment=='PROD') {
	WebUI.setText(findTestObject('SignInPage/emailField'), 'qaautomation2@prod.com')
}
else {
	WebUI.setText(findTestObject('SignInPage/emailField'), 'qaautomation2@staging.com')
}

WebUI.setText(findTestObject('SignInPage/passwordField'), GlobalVariable.password)

WebUI.enhancedClick(findTestObject('SignInPage/signInBtn'))

WebUI.waitForElementVisible(findTestObject('TopNavigationMenu/scoutsTab'), 60)

WebUI.verifyElementNotPresent(findTestObject('TeamPage/Dashboard/advancedStatsTitle'), 0)

WebUI.mouseOver(findTestObject('TeamPage/Dashboard/Boxscore/advancedBtn'))

WebUI.verifyElementPresent(findTestObject('TeamPage/Dashboard/Boxscore/advancedStatsToolTip'), 0)

WebUI.mouseOver(findTestObject('TeamPage/Dashboard/Boxscore/per40Btn'))

WebUI.verifyElementPresent(findTestObject('TeamPage/Dashboard/Boxscore/advancedStatsToolTip'), 0)

WebUI.enhancedClick(findTestObject('TopNavigationMenu/playsTab'))

WebUI.verifyElementNotPresent(findTestObject('PlaysPage/playsTab'), 0)

WebUI.enhancedClick(findTestObject('TopNavigationMenu/videosTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/addVideoBtn (1)'))

WebUI.verifyElementNotPresent(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/fromSynergyBtn'), 0)

def imgDir = RunConfiguration.getProjectDir() + '/Data Files/Videos/FS Test Video.mp4'

WebUI.uploadFile(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/videoUploadInput'), imgDir)

WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/Videos/row1inVideos'))

WebUI.enhancedClick(findTestObject('TopNavigationMenu/scoutsTab'))

WebUI.verifyElementNotPresent(findTestObject('ScoutsPage/PlayerScouts/playerScoutsTab'), 0)

WebUI.mouseOver(findTestObject('ScoutsPage/OpponentScouts/oppScoutNameFromGrid', [('scoutName') : (GlobalVariable.data).getValue(
                'scoutName', 5)]))

WebUI.enhancedClick(findTestObject('ScoutsPage/OpponentScouts/scoutContextEllipsisBtn', [('scoutName') : (GlobalVariable.data).getValue(
                'scoutName', 5)]))

WebUI.verifyElementNotPresent(findTestObject('ScoutsPage/ScoutContextMenu/presenterMode'), 0)

WebUI.verifyElementNotPresent(findTestObject('ScoutsPage/ScoutContextMenu/mobileAccessBtn'), 0)

WebUI.verifyElementNotPresent(findTestObject('ScoutsPage/ScoutContextMenu/mobileUsageBtn'), 0)

WebUI.enhancedClick(findTestObject('ScoutsPage/OpponentScouts/selectOpponentFromGrid', [('scoutName') : (GlobalVariable.data).getValue(
                'scoutName', 5)]))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/IndividualBoxscoreTile/individualBoxscoreTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/optionsTab'))

WebUI.verifyElementAttributeValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/USGPerct_ChkBox'), 'data-enabled', 
    'false', 0)

WebUI.verifyElementAttributeValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/Plus-Minus_ChkBox'), 'data-enabled', 
    'false', 0)

WebUI.verifyElementAttributeValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/eFG Perct_ChkBox'), 'data-enabled', 
    'false', 0)

WebUI.verifyElementAttributeValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/TSPerct_ChkBox'), 'data-enabled', 
    'false', 0)

WebUI.verifyElementAttributeValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/ORBPerct_ChkBox'), 'data-enabled', 
    'false', 0)

WebUI.verifyElementAttributeValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/DREB Perct_ChkBox'), 'data-enabled', 
    'false', 0)

WebUI.verifyElementAttributeValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/AST Perct_ChkBox'), 'data-enabled', 
    'false', 0)

WebUI.verifyElementAttributeValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/TOPerct_ChkBox'), 'data-enabled', 
    'false', 0)

WebUI.verifyElementAttributeValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/STL Perct'), 'data-enabled', 
    'false', 0)

WebUI.verifyElementAttributeValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/BLK Perct_ChkBox'), 'data-enabled', 
    'false', 0)

WebUI.verifyElementNotPresent(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/per40StatTypeRadioBtn'), 0)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/CumulativeBoxscoreTile/cumulativeBoxscoreTile'))

WebUI.verifyElementNotPresent(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/per40StatTypeRadioBtn'), 0)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/cancelTileBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamAdvancedStatsTile/teamAdvancedStatsTile'))

WebUI.verifyElementNotPresent(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'), 0)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ClutchStatsTile/clutchStatsTile'))

WebUI.verifyElementNotPresent(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'), 0)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/LineupStatsTile/lineupStatsTile'))

WebUI.verifyElementNotPresent(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'), 0)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/PersonnelTiles/Tiles Menu_Personnel'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/statsTab'))

WebUI.verifyElementNotPresent(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/per40StatTypeRadioBtn'), 0)

WebUI.enhancedClick(findTestObject('Object Repository/ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/tilesMenuLeaders'))

WebUI.verifyElementNotPresent(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/per40StatTypeRadioBtn'), 0)

WebUI.enhancedClick(findTestObject('Object Repository/ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/3PointShootersTile/3PointShootersTile'))

WebUI.verifyElementNotPresent(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/per40StatTypeRadioBtn'), 0)

WebUI.enhancedClick(findTestObject('Object Repository/ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/FTShootersTile/FTShootersTile'))

WebUI.verifyElementNotPresent(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/per40StatTypeRadioBtn'), 0)

WebUI.enhancedClick(findTestObject('Object Repository/ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/Rebounds/reboundsTile'))

WebUI.verifyElementNotPresent(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/per40StatTypeRadioBtn'), 0)

WebUI.enhancedClick(findTestObject('Object Repository/ScoutsPage/ScoutBuilder/Tiles/LeadersTiles/BallControlTile/ballControlTile'))

WebUI.verifyElementNotPresent(findTestObject('ScoutsPage/ScoutBuilder/Tiles/StatsOptionsTab/per40StatTypeRadioBtn'), 0)

WebUI.closeBrowser()
