import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.common.WebUiCommonHelper as WebUiCommonHelper
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.configuration.RunConfiguration


WebUI.openBrowser(GlobalVariable.URL)
WebUI.maximizeWindow()

WebUI.setText(findTestObject('SignInPage/emailField'), GlobalVariable.email)

WebUI.setText(findTestObject('SignInPage/passwordField'), GlobalVariable.password)

WebUI.enhancedClick(findTestObject('SignInPage/signInBtn'))

WebUI.delay(2)

WebUI.waitForElementVisible(findTestObject('TopNavigationMenu/scoutsTab'), 60)


WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Splits/last5Tab'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Splits/winsVsLossesTab'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Splits/homeVsAwayTab'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Splits/allGamesTab'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TopNavigationMenu/seasonDrpDwn'))

WebUI.enhancedClick(findTestObject('TopNavigationMenu/seasonDrpDwnValue', [('seasonValue') : (GlobalVariable.data).getValue("seasonDrpDwn", 13)]))

WebUI.delay(3)
WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/FastScoutFactors/FSFactorsChartIcon'))

WebUI.delay(1)

WebUI.verifyElementVisible(findTestObject('TeamPage/Dashboard/FastScoutFactors/FSFactorsChartGraph'))

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/FastScoutFactors/FFChartOptionSelect', [('FFOption') : "TS%"]))

WebUI.delay(1)

WebUI.verifyElementVisible(findTestObject('TeamPage/Dashboard/FastScoutFactors/FSFactorsChartGraph'))

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/FastScoutFactors/FFChartOptionSelect', [('FFOption') : "TO%"]))

WebUI.delay(1)

WebUI.verifyElementVisible(findTestObject('TeamPage/Dashboard/FastScoutFactors/FSFactorsChartGraph'))

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/FastScoutFactors/FFChartOptionSelect', [('FFOption') : "AST%"]))

WebUI.delay(1)

WebUI.verifyElementVisible(findTestObject('TeamPage/Dashboard/FastScoutFactors/FSFactorsChartGraph'))

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/FastScoutFactors/FFChartOptionSelect', [('FFOption') : "ORB%"]))

WebUI.delay(1)

WebUI.verifyElementVisible(findTestObject('TeamPage/Dashboard/FastScoutFactors/FSFactorsChartGraph'))

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/FastScoutFactors/FFChartOptionSelect', [('FFOption') : "DRB%"]))

WebUI.delay(1)

WebUI.verifyElementVisible(findTestObject('TeamPage/Dashboard/FastScoutFactors/FSFactorsChartGraph'))

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/FastScoutFactors/FFChartOptionSelect', [('FFOption') : "FT-R"]))

WebUI.delay(1)

WebUI.verifyElementVisible(findTestObject('TeamPage/Dashboard/FastScoutFactors/FSFactorsChartGraph'))

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/FastScoutFactors/FFChartOptionSelect', [('FFOption') : "FT%"]))

WebUI.delay(1)

WebUI.verifyElementVisible(findTestObject('TeamPage/Dashboard/FastScoutFactors/FSFactorsChartGraph'))

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/FastScoutFactors/FSFactorsTableIcon'))

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Pace/paceChartIcon'))

WebUI.verifyElementVisible(findTestObject('TeamPage/Dashboard/Pace/paceChartGraph'))

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Pace/paceTableIcon'))

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/rankingDrpDwnIcn'))

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/selectRankingDrpDwnValue', [('rankingDrpDwnVal') : "None"]))
WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/rankingDrpDwnIcn'))

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/selectRankingDrpDwnValue', [('rankingDrpDwnVal') : (GlobalVariable.data).getValue("rankingsDrpDwn", 13)]))

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/totalsBtn'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/advancedBtn'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/per40Btn'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/averagesBtn'))

WebUI.enhancedClick(findTestObject('TopNavigationMenu/seasonDrpDwn'))

WebUI.enhancedClick(findTestObject('TopNavigationMenu/seasonDrpDwnValue', [('seasonValue') : (GlobalVariable.data).getValue("seasonDrpDwn", 13)]))

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/scheduleTab'))


WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/last5Btn'))

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/winsBtn'))

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/lossesBtn'))

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/homeBtn'))

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/awayBtn'))

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/vsTeamDrpDwnIcn'))

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/vsTeamNameFrmDrpDwn', [('teamName') : (GlobalVariable.data).getValue("teamName", 13)]))

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/allGamesBtn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TopNavigationMenu/seasonDrpDwn'))

WebUI.enhancedClick(findTestObject('TopNavigationMenu/seasonDrpDwnValue', [('seasonValue') : (GlobalVariable.data).getValue("seasonDrpDwn", 13)]))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/last5Btn'))

//WebUI.enhancedClick(findTestObject('TeamPage/Schedule/selectAllChkBox'))
WebUI.enhancedClick(findTestObject('TeamPage/Schedule/printIcon'))
WebUI.delay(2)
WebUI.sendKeys(findTestObject('TeamPage/Schedule/cancelBtnPrintModal'), Keys.chord(Keys.ESCAPE))
WebUI.delay(3)
WebUI.enhancedClick(findTestObject('TeamPage/Roster/rosterTab'))

WebUI.delay(3)

WebUI.waitForElementClickable(findTestObject('TeamPage/Roster/2playersPerRow'), 0)

WebUI.enhancedClick(findTestObject('TeamPage/Roster/2playersPerRow'))
WebUI.delay(3)

WebUI.waitForElementClickable((findTestObject('TeamPage/SelfScouts/selfScoutsTab')), 10)
WebUI.enhancedClick(findTestObject('TeamPage/SelfScouts/selfScoutsTab'))

WebUI.enhancedClick(findTestObject('TopNavigationMenu/opponentsTab'))

WebUI.enhancedClick(findTestObject('OpponentsPage/scheduledTab'))

WebUI.enhancedClick(findTestObject('OpponentsPage/allTeamsTab'))

WebUI.enhancedClick(findTestObject('OpponentsPage/scheduledTab'))

WebUI.enhancedClick(findTestObject('TopNavigationMenu/playsTab'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TopNavigationMenu/videosTab'))

WebUI.closeBrowser()

