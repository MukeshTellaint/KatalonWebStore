import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.common.WebUiCommonHelper as WebUiCommonHelper
import org.openqa.selenium.WebElement as WebElement

WebUI.openBrowser(GlobalVariable.URL)

WebUI.setText(findTestObject('SignInPage/emailField'), GlobalVariable.email)

WebUI.setText(findTestObject('SignInPage/passwordField'), GlobalVariable.password)

WebUI.enhancedClick(findTestObject('SignInPage/signInBtn'))

WebUI.waitForElementVisible(findTestObject('TopNavigationMenu/scoutsTab'), 60)

WebUI.enhancedClick(findTestObject('TopNavigationMenu/opponentsTab'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('OpponentsPage/scheduledTab'))

WebUI.delay(3)

WebUI.enhancedClick(findTestObject('Object Repository/TopNavigationMenu/seasonDrpDwn'))

WebUI.enhancedClick(findTestObject('Object Repository/TopNavigationMenu/seasonDrpDwnValue',[('seasonValue') : (GlobalVariable.data).getValue("seasonDrpDwn", 11)]))
WebUI.enhancedClick(findTestObject('Boxscore Page/scheduledTabBoxScoreRow1'))

WebUI.delay(5)

WebUI.enhancedClick(findTestObject('Boxscore Page/playByPlayTab'))

WebUI.delay(5)

WebUI.enhancedClick(findTestObject('Boxscore Page/boxScoreTab'))

WebUI.delay(5)

WebUI.enhancedClick(findTestObject('Boxscore Page/backToCalendarIcn'))

WebUI.delay(3)

WebUI.enhancedClick(findTestObject('TopNavigationMenu/opponentsTab'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('OpponentsPage/allTeamsTab'))

WebUI.delay(1)

WebUI.enhancedClick(GlobalVariable.allTeams1)

WebUI.delay(3)

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/scheduleTab'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('Object Repository/TopNavigationMenu/seasonDrpDwn'))
WebUI.delay(3)
WebUI.enhancedClick(findTestObject('Object Repository/TopNavigationMenu/seasonDrpDwnValue',[('seasonValue') : (GlobalVariable.data).getValue("seasonDrpDwn", 11)]))

WebUI.delay(3)

WebUI.enhancedClick(findTestObject('Boxscore Page/scheduledTabBoxScoreRow1'))

WebUI.delay(5)

WebUI.enhancedClick(findTestObject('Boxscore Page/playByPlayTab'))

WebUI.delay(3)

WebUI.enhancedClick(findTestObject('Boxscore Page/boxScoreTab'))

WebUI.delay(5)

WebUI.enhancedClick(findTestObject('Boxscore Page/backToCalendarIcn'))

WebUI.delay(2)

WebUI.closeBrowser()

