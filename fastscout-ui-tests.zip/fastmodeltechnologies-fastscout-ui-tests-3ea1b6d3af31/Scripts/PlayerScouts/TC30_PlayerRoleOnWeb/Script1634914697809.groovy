import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys



WebUI.openBrowser(GlobalVariable.URL)

WebUI.maximizeWindow()

WebUI.setText(findTestObject('SignInPage/emailField'), GlobalVariable.playerScout)

WebUI.setText(findTestObject('SignInPage/passwordField'), GlobalVariable.playerPwd)

WebUI.enhancedClick(findTestObject('SignInPage/signInBtn'))

WebUI.enhancedClick(findTestObject('TopNavigationMenu/seasonDrpDwn'))

WebUI.enhancedClick(findTestObject('TopNavigationMenu/seasonDrpDwnValue', [('seasonValue') : GlobalVariable.data.getValue('seasonDrpDwn', 11)]))

WebUI.waitForElementPresent(findTestObject('TeamPage/Dashboard/Boxscore/BoxScoreTab'),20)
WebUI.mouseOver(findTestObject('TeamPage/Dashboard/Boxscore/BoxScoreTab'))

WebUI.delay(2)

WebUI.mouseOver(findTestObject('TeamPage/Dashboard/Boxscore/BoxScoreTextField'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/per40Btn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/advancedBtn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/totalsBtn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/averagesBtn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Splits/last5Tab'))

WebUI.mouseOver(findTestObject('TeamPage/Dashboard/Boxscore/BoxScoreTab'))

WebUI.delay(2)

WebUI.mouseOver(findTestObject('TeamPage/Dashboard/Boxscore/BoxScoreTextField'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/per40Btn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/advancedBtn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/totalsBtn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/averagesBtn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Splits/winsVsLossesTab'))

WebUI.mouseOver(findTestObject('TeamPage/Dashboard/Boxscore/BoxScoreTab'))

WebUI.delay(2)

WebUI.mouseOver(findTestObject('TeamPage/Dashboard/Boxscore/BoxScoreTextField'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/per40Btn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/advancedBtn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/totalsBtn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/averagesBtn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Splits/homeVsAwayTab'))

WebUI.mouseOver(findTestObject('TeamPage/Dashboard/Boxscore/BoxScoreTab'))

WebUI.delay(2)

WebUI.mouseOver(findTestObject('TeamPage/Dashboard/Boxscore/BoxScoreTextField'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/per40Btn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/advancedBtn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/totalsBtn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/averagesBtn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Splits/confVsNonConfTab'))

WebUI.mouseOver(findTestObject('TeamPage/Dashboard/Boxscore/BoxScoreTab'))

WebUI.delay(2)

WebUI.mouseOver(findTestObject('TeamPage/Dashboard/Boxscore/BoxScoreTextField'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/per40Btn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/advancedBtn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/totalsBtn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/averagesBtn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/scheduleTab'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/conferenceBtn'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/last5Btn'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/winsBtn'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/lossesBtn'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/homeBtn'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/awayBtn'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/vsTeamDrpDwnIcn'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/vsTeamNameFrmDrpDwn', [('teamName') : GlobalVariable.data.getValue(
				'scoutName', 5)]))

WebUI.enhancedClick(findTestObject('Boxscore Page/scheduledTabBoxScoreRow1'))

WebUI.enhancedClick(findTestObject('Boxscore Page/playByPlayTab'))

WebUI.enhancedClick(findTestObject('Boxscore Page/boxScoreTab'))

WebUI.delay(5)

WebUI.enhancedClick(findTestObject('Boxscore Page/backToCalendarIcn'))

WebUI.delay(3)

WebUI.enhancedClick(findTestObject('TeamPage/Roster/rosterTab'))

WebUI.delay(5)

WebUI.enhancedClick(findTestObject('TeamPage/Roster/1playerPerRow'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('TeamPage/Roster/2playersPerRow'))

WebUI.enhancedClick(findTestObject('TeamPage/SelfScouts/selfScoutsTab'))

WebUI.delay(5)

WebUI.enhancedClick(findTestObject('TopNavigationMenu/playsTab'))

WebUI.waitForElementVisible(findTestObject('PlaysPage/ChoosePlay'), 10)
WebUI.scrollToElement(findTestObject('PlaysPage/ChoosePlay'), 10)
WebUI.waitForElementClickable(findTestObject('PlaysPage/ChoosePlay'), 10)
WebUI.enhancedClick(findTestObject('PlaysPage/ChoosePlay'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('PlaysPage/2FramesPerRow'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('PlaysPage/3FramesPerRow'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('PlaysPage/1FramePerRow'))

WebUI.enhancedClick(findTestObject('PlaysPage/ChoosePlayVideo'))

/*
 * WebUI.enhancedClick(findTestObject('PlaysPage/LeftArrow'))
 * 
 * WebUI.enhancedClick(findTestObject('PlaysPage/RightArrow'))
 */

WebUI.enhancedClick(findTestObject('PlaysPage/ExitVideo'))

WebUI.enhancedClick(findTestObject('PlaysPage/playBooksTab'))

WebUI.enhancedClick(findTestObject('PlaysPage/ChoosePlay'))

WebUI.waitForElementVisible(findTestObject('PlaysPage/ShowVideoTab'), 10)

WebUI.enhancedClick(findTestObject('PlaysPage/ShowVideoTab'))

WebUI.enhancedClick(findTestObject('PlaysPage/VideoTab/SelectVideo'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('PlaysPage/ExitVideo'))

WebUI.enhancedClick(findTestObject('TopNavigationMenu/videosTab'))

WebUI.enhancedClick(findTestObject('PlaysPage/VideoTab/SelectVideo'))

WebUI.enhancedClick(findTestObject('PlaysPage/ExitVideo'))

WebUI.enhancedClick(findTestObject('TopNavigationMenu/scoutsTab'))

WebUI.getText(findTestObject('PlaysPage/ScoutTabList'))
/*
 * WebUI.mouseOver(findTestObject('ScoutsPage/OpponentScouts/
 * oppScoutNameFromGrid', [('scoutName') :
 * (GlobalVariable.data).getValue("teamName", 32)]))
 * 
 * WebUI.enhancedClick(findTestObject('ScoutsPage/OpponentScouts/
 * oppScoutNameFromGrid', [('scoutName') :
 * (GlobalVariable.data).getValue("teamName", 32)]))
 * 
 * WebUI.verifyElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/
 * TilesOnReport/ImageTile'))
 * 
 * WebUI.waitForElementVisible(findTestObject('ScoutsPage/ScoutBuilder/TopMenu/
 * doneBtn'), 10)
 * 
 * WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/TopMenu/doneBtn')
 * )
 * 
 * WebUI.enhancedClick(findTestObject('Object
 * Repository/ScoutsPage/SubNavigation/selfScoutsTab'))
 * 
 * WebUI.mouseOver(findTestObject('Object
 * Repository/ScoutsPage/SelfScouts/selfScoutNameFromGrid', [('scoutName') :
 * (GlobalVariable.data).getValue("teamName", 13)]))
 * 
 * WebUI.enhancedClick(findTestObject('Object
 * Repository/ScoutsPage/SelfScouts/selfScoutNameFromGrid', [('scoutName') :
 * (GlobalVariable.data).getValue("teamName", 13)]))
 * 
 * WebUI.verifyElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/
 * TilesOnReport/ImageTile'))
 * 
 * WebUI.waitForElementVisible(findTestObject('ScoutsPage/ScoutBuilder/TopMenu/
 * doneBtn'), 10)
 * 
 * WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/TopMenu/doneBtn')
 * )
 * 
 * WebUI.enhancedClick(findTestObject('ScoutsPage/OpponentScouts/
 * scoutContextEllipsisBtn', [('scoutName') :
 * (GlobalVariable.data).getValue("teamName", 13)]))
 */
WebUI.closeBrowser()

