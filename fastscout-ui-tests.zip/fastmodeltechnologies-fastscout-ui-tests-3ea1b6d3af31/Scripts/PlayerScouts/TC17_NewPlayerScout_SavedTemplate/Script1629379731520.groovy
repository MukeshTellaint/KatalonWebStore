import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.common.WebUiCommonHelper as WebUiCommonHelper
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.configuration.RunConfiguration


WebUI.openBrowser(GlobalVariable.URL)
WebUI.maximizeWindow()
WebUI.setText(findTestObject('SignInPage/emailField'), GlobalVariable.emailscout)

WebUI.setText(findTestObject('SignInPage/passwordField'), GlobalVariable.passwordscout)

WebUI.enhancedClick(findTestObject('SignInPage/signInBtn'))

WebUI.waitForElementVisible(findTestObject('TopNavigationMenu/scoutsTab'), 60)

WebUI.enhancedClick(findTestObject('TopNavigationMenu/scoutsTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/newScoutBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/savedTemplateDrpDwnValue'))

WebUI.sendKeys(findTestObject('ScoutsPage/NewScoutModal/savedTemplateDrpDwnValue'), '7')

WebUI.sendKeys(findTestObject('ScoutsPage/NewScoutModal/savedTemplateDrpDwnValue'), Keys.chord(Keys.ENTER))
WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/scoutingReportNameTxtFld'))

WebUI.sendKeys(findTestObject('ScoutsPage/NewScoutModal/scoutingReportNameTxtFld'), (GlobalVariable.data).getValue("scoutName", 14))

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/createBtn'))

WebUI.delay(4)
WebUI.waitForElementVisible(findTestObject('ScoutsPage/PlayerScouts/Player Scout Personnel Tiles/addPlayer1Btn'), 30)
WebUI.enhancedClick(findTestObject('ScoutsPage/PlayerScouts/Player Scout Personnel Tiles/addPlayer1Btn'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/PlayerScouts/Player Scout Personnel Tiles/selectPlayerChkBox'))

WebUI.delay(1)

WebUI.sendKeys(findTestObject('ScoutsPage/PlayerScouts/Player Scout Personnel Tiles/playerScoutLeagueDropdown'), 'D')

WebUI.sendKeys(findTestObject('ScoutsPage/PlayerScouts/Player Scout Personnel Tiles/playerScoutLeagueDropdown'), Keys.chord(
		Keys.DOWN))

WebUI.sendKeys(findTestObject('ScoutsPage/PlayerScouts/Player Scout Personnel Tiles/playerScoutLeagueDropdown'), Keys.chord(
		Keys.ENTER))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/PlayerScouts/Player Scout Personnel Tiles/playerScoutTeamDropdown'))

WebUI.sendKeys(findTestObject('ScoutsPage/PlayerScouts/Player Scout Personnel Tiles/playerScoutTeamDropdown'), 'indiana')

WebUI.sendKeys(findTestObject('ScoutsPage/PlayerScouts/Player Scout Personnel Tiles/playerScoutTeamDropdown'), Keys.chord(
		Keys.ENTER))

WebUI.enhancedClick(findTestObject('ScoutsPage/PlayerScouts/Player Scout Personnel Tiles/playerScoutPlayerDropdown'))

WebUI.sendKeys(findTestObject('ScoutsPage/PlayerScouts/Player Scout Personnel Tiles/playerScoutPlayerDropdown'), Keys.chord(
		Keys.DOWN))

WebUI.sendKeys(findTestObject('ScoutsPage/PlayerScouts/Player Scout Personnel Tiles/playerScoutPlayerDropdown'), Keys.chord(
		Keys.ENTER))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

def imgDir = RunConfiguration.getProjectDir() + '/Data Files/Images/FS Test Image.png'

WebUI.uploadFile(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ImageTile/uploadImage'), imgDir)

WebUI.delay(2)

WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ImageTile/uploadedImage(PresenceOf)'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Pagination/selectPageBtn', [('pageNo') : "2"]))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ShotChartTiles/shotChartsSelectPlayerBtn'))

WebUI.delay(1)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/ShotChartTiles/Select Player Radio button (PlayerShotChartTile)'))

WebUI.enhancedClick(findTestObject('ScoutsPage/PlayerScouts/Player Scout Personnel Tiles/playerScoutPlayerDropdown'))

WebUI.sendKeys(findTestObject('ScoutsPage/PlayerScouts/Player Scout Personnel Tiles/playerScoutPlayerDropdown'), Keys.chord(
		Keys.DOWN))

WebUI.sendKeys(findTestObject('ScoutsPage/PlayerScouts/Player Scout Personnel Tiles/playerScoutPlayerDropdown'), Keys.chord(
		Keys.ENTER))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/TopMenu/Presenter Mode/presenterModeIcon'))

WebUI.delay(2)

WebUI.sendKeys(findTestObject('TopNavigationMenu/Root'), Keys.chord(Keys.TAB))

WebUI.sendKeys(findTestObject('TopNavigationMenu/Root'), Keys.chord(Keys.TAB))

WebUI.sendKeys(findTestObject('TopNavigationMenu/Root'), Keys.chord(Keys.TAB))

WebUI.sendKeys(findTestObject('TopNavigationMenu/Root'), Keys.chord(Keys.TAB))

WebUI.sendKeys(findTestObject('TopNavigationMenu/Root'), Keys.chord(Keys.TAB))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/TopMenu/Presenter Mode/exitPresenterModeBtn'))

WebUI.delay(3)

WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/TopMenu/doneBtn'), 30)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/TopMenu/doneBtn'))
WebUI.waitForElementVisible(findTestObject('ScoutsPage/PlayerScouts/playerScouts1stRow', [('scoutName') : (GlobalVariable.data).getValue("scoutName", 14)]),20)
WebUI.mouseOver(findTestObject('ScoutsPage/PlayerScouts/playerScouts1stRow', [('scoutName') : (GlobalVariable.data).getValue("scoutName", 14)]))

WebUI.waitForElementVisible(findTestObject('ScoutsPage/PlayerScouts/playerScoutContextMenu', [('playerScoutName') : (GlobalVariable.data).getValue("scoutName", 14)]),20)
//WebUI.mouseOver(findTestObject('ScoutsPage/PlayerScouts/playerScoutContextMenu', [('playerScoutName') : (GlobalVariable.data).getValue("scoutName", 14)]))
WebUI.enhancedClick(findTestObject('ScoutsPage/PlayerScouts/playerScoutContextMenu', [('playerScoutName') : (GlobalVariable.data).getValue("scoutName", 14)]))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutContextMenu/archiveBtn'))

WebUI.waitForElementClickable(findTestObject('ScoutsPage/SubNavigation/archivedTab'),20)
WebUI.enhancedClick(findTestObject('ScoutsPage/SubNavigation/archivedTab'))

WebUI.mouseOver(findTestObject('ScoutsPage/Archived/archivedScouts1stRow'))

WebUI.enhancedClick(findTestObject('ScoutsPage/Archived/scoutArchiveEllipsisIcn'))

WebUI.waitForElementClickable(findTestObject('ScoutsPage/Archived/deleteBtn'), 0)

WebUI.mouseOver(findTestObject('ScoutsPage/Archived/deleteBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/Archived/deleteBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/Archived/confirmDeleteScoutBtn'))

WebUI.closeBrowser()