import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.common.WebUiCommonHelper as WebUiCommonHelper
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.util.KeywordUtil
import java.awt.image.BufferedImage
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.text.DecimalFormat
import javax.imageio.ImageIO
import org.openqa.selenium.WebDriver
import com.kms.katalon.core.webui.driver.DriverFactory
import common.UiCheck


WebUI.openBrowser(GlobalVariable.URL)
WebUI.maximizeWindow()

WebDriver driver = DriverFactory.getWebDriver()
WebUI.setText(findTestObject('SignInPage/emailField'), GlobalVariable.visualTest)

WebUI.setText(findTestObject('SignInPage/passwordField'), GlobalVariable.password)

WebUI.enhancedClick(findTestObject('SignInPage/signInBtn'))

WebUI.delay(2)

WebUI.waitForElementVisible(findTestObject('TopNavigationMenu/scoutsTab'), 60)

WebUI.enhancedClick(findTestObject('TopNavigationMenu/seasonDrpDwn'))

WebUI.enhancedClick(findTestObject('TopNavigationMenu/seasonDrpDwnValue', [('seasonValue') : (GlobalVariable.data).getValue("seasonDrpDwn", 34)]))

WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 30)

allGames_act = UiCheck.takeSnap(driver, 500,'All_Games_actual.png')
UiCheck.compareImages(UiCheck.loadFile('All_Games_org.png'), allGames_act,'allGames_Diff.png')

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Splits/last5Tab'))

WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 30)

Last5_act = UiCheck.takeSnap(driver, 500,'Last5_act.png')
UiCheck.compareImages(UiCheck.loadFile('Last5_org.png'), Last5_act,'Last5_Diff.png')

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Splits/winsVsLossesTab'))

WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 30)

winsVsLoss_act = UiCheck.takeSnap(driver, 500,'winsVsLoss_actual.png')
UiCheck.compareImages(UiCheck.loadFile('winsVsLoss_org.png'), winsVsLoss_act,'winsVsLoss_Diff.png')

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Splits/homeVsAwayTab'))
WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 30)

homeVsAway_act = UiCheck.takeSnap(driver, 500,'homeVsAway_act.png')
UiCheck.compareImages(UiCheck.loadFile('homeVsAway_org.png'), homeVsAway_act,'homeVsAway_Diff.png')

WebUI.enhancedClick(findTestObject('Object Repository/TeamPage/Dashboard/Splits/confVsNonConfTab'))
WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 30)

confvsNonConf_act = UiCheck.takeSnap(driver, 500,'confvsNonConf_act.png')
UiCheck.compareImages(UiCheck.loadFile('confvsNonConf_org.png'), confvsNonConf_act,'confvsNonConf_Diff.png')
WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Splits/allGamesTab'))
WebUI.delay(2)
WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/FastScoutFactors/FSFactorsChartIcon'))
WebUI.delay(1)
WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 30)
WebUI.verifyElementVisible(findTestObject('TeamPage/Dashboard/FastScoutFactors/FSFactorsChartGraph'))
WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Pace/paceChartIcon'))

WebUI.verifyElementVisible(findTestObject('TeamPage/Dashboard/Pace/paceChartGraph'))
FSFactorsGraph_act = UiCheck.takeSnap(driver, 500,'FSFactorsChartIcon_act.png')
UiCheck.compareImages(UiCheck.loadFile('FSFactorsGraph_org.png'), FSFactorsGraph_act,'FSFactorsGraph_Diff.png')

WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/FastScoutFactors/FSFactorsTableIcon'))
WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Pace/paceTableIcon'))
WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/totalsBtn'))
WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 30)
BoxScore_Totals_act = UiCheck.takeSnap(driver, 500,'BoxScore_Totals_act.png')
UiCheck.compareImages(UiCheck.loadFile('BoxScore_Totals_org.png'), BoxScore_Totals_act,'BoxScore_Totals_Diff.png')
WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/advancedBtn'))

WebUI.delay(1)
WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 30)
BoxScore_advanced_act = UiCheck.takeSnap(driver, 500,'BoxScore_advanced_act.png')
UiCheck.compareImages(UiCheck.loadFile('BoxScore_advanced_org.png'), BoxScore_advanced_act,'BoxScore_advanced_Diff.png')
WebUI.delay(1)
WebUI.enhancedClick(findTestObject('TeamPage/Dashboard/Boxscore/per40Btn'))
WebUI.delay(1)
WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 30)
BoxScore_per40_act = UiCheck.takeSnap(driver, 500,'BoxScore_per40_act.png')
UiCheck.compareImages(UiCheck.loadFile('BoxScore_per40_org.png'), BoxScore_per40_act,'BoxScore_per40_Diff.png')
WebUI.delay(1)
WebUI.closeBrowser()

