import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import org.openqa.selenium.WebDriver
import com.kms.katalon.core.webui.driver.DriverFactory
import common.UiCheck

WebUI.openBrowser(GlobalVariable.URL)
WebUI.maximizeWindow()
WebDriver driver = DriverFactory.getWebDriver()
WebUI.setText(findTestObject('SignInPage/emailField'), GlobalVariable.visualTest)

WebUI.setText(findTestObject('SignInPage/passwordField'), GlobalVariable.password)

WebUI.enhancedClick(findTestObject('SignInPage/signInBtn'))

WebUI.delay(2)

WebUI.waitForElementVisible(findTestObject('TopNavigationMenu/scoutsTab'), 60)
WebUI.enhancedClick(findTestObject('TopNavigationMenu/seasonDrpDwn'))

WebUI.enhancedClick(findTestObject('TopNavigationMenu/seasonDrpDwnValue', [('seasonValue') : (GlobalVariable.data).getValue("seasonDrpDwn", 39)]))

WebUI.enhancedClick(findTestObject('Object Repository/TeamPage/Roster/rosterTab'))

WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 50, FailureHandling.STOP_ON_FAILURE)
WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon2'), 50, FailureHandling.STOP_ON_FAILURE)
WebUI.waitForElementClickable(findTestObject('Object Repository/TeamPage/Roster/2playersPerRow'), 30)
roster_act = UiCheck.takeSnap(driver, 500,'Roster_actual.png')
UiCheck.compareImages(UiCheck.loadFile('Roster_org.png'), roster_act,'Roster_Diff.png')

WebUI.enhancedClick(findTestObject('Object Repository/TeamPage/Roster/2playersPerRow'))

WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 50, FailureHandling.STOP_ON_FAILURE)
roster_2Players_act = UiCheck.takeSnap(driver, 500,'Roster_2Players_actual.png')
UiCheck.compareImages(UiCheck.loadFile('Roster_2Players_org.png'), roster_2Players_act,'Roster_2Players_Diff.png')
WebUI.enhancedClick(findTestObject('Object Repository/TeamPage/Roster/sortDrpDwnIcon'))
WebUI.enhancedClick(findTestObject('Object Repository/TeamPage/Roster/pointsPerGameDrpDwn'))

WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 50, FailureHandling.STOP_ON_FAILURE)
roster_ppg_act = UiCheck.takeSnap(driver, 500,'Roster_ppg_act.png')
UiCheck.compareImages(UiCheck.loadFile('Roster_ppg_org.png'), roster_ppg_act,'Roster_ppg_Diff.png')

WebUI.enhancedClick(findTestObject('TeamPage/PlayerPage/playerNameFromRosterGrid', [('playerName') : (GlobalVariable.data).getValue("recruitName", 39)]))
WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 50, FailureHandling.STOP_ON_FAILURE)

WebUI.delay(3)

WebUI.enhancedClick(findTestObject('TeamPage/PlayerPage/gameLogTab'))
WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 50, FailureHandling.STOP_ON_FAILURE)
roster_gameLog_act = UiCheck.takeSnap(driver, 500,'Roster_gameLog_act.png')
UiCheck.compareImages(UiCheck.loadFile('Roster_gameLog_org.png'), roster_gameLog_act,'Roster_gameLog_Diff.png')


