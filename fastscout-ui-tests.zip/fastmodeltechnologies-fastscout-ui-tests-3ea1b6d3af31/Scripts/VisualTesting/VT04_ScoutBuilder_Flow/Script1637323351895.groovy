import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import org.openqa.selenium.WebDriver
import com.kms.katalon.core.webui.driver.DriverFactory
import common.UiCheck

WebUI.openBrowser(GlobalVariable.URL)
WebUI.maximizeWindow()
WebDriver driver = DriverFactory.getWebDriver()
WebUI.setText(findTestObject('SignInPage/emailField'), GlobalVariable.visualTest)
WebUI.setText(findTestObject('SignInPage/passwordField'), GlobalVariable.password)
WebUI.enhancedClick(findTestObject('SignInPage/signInBtn'))

WebUI.delay(2)

WebUI.waitForElementVisible(findTestObject('TopNavigationMenu/scoutsTab'), 60)
WebUI.enhancedClick(findTestObject('TopNavigationMenu/scoutsTab'))
WebUI.enhancedClick(findTestObject('ScoutsPage/OpponentScouts/oppScoutNameFromGrid', [('scoutName') : "Michigan St."]))
WebUI.waitForPageLoad(30)
WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon2'), 50, FailureHandling.STOP_ON_FAILURE)
WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 50, FailureHandling.STOP_ON_FAILURE)
WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'))
WebUI.mouseOver(findTestObject('Object Repository/ScoutsPage/ScoutBuilder/TopMenu/doneBtn'))
scoutBuilder_PG1_act = UiCheck.takeSnap(driver, 500,'ScoutBuilder_PG1_act.png')
UiCheck.compareImages(UiCheck.loadFile('ScoutBuilder_PG1_org.png'), scoutBuilder_PG1_act,'ScoutBuilder_PG1_Diff.png')
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Pagination/selectPageBtn', [('pageNo') : "2"]))
WebUI.delay(3)
scoutBuilder_PG2_act = UiCheck.takeSnap(driver, 500,'ScoutBuilderPG2_act.png')
UiCheck.compareImages(UiCheck.loadFile('ScoutBuilder_PG2_org.png'), scoutBuilder_PG2_act,'ScoutBuilder_PG2_Diff.png')
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Pagination/selectPageBtn', [('pageNo') : "3"]))
WebUI.delay(3)
scoutBuilder_PG3_act = UiCheck.takeSnap(driver, 500,'ScoutBuilderPG3_act.png')
UiCheck.compareImages(UiCheck.loadFile('ScoutBuilder_PG3_org.png'), scoutBuilder_PG3_act,'ScoutBuilder_PG3_Diff.png')
WebUI.closeBrowser()



