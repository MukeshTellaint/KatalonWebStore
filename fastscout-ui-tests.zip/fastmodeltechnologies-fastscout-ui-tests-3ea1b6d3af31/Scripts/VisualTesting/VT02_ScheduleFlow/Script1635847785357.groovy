import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import org.openqa.selenium.WebDriver
import com.kms.katalon.core.webui.driver.DriverFactory
import common.UiCheck


WebUI.openBrowser(GlobalVariable.URL)
WebUI.maximizeWindow()
WebDriver driver = DriverFactory.getWebDriver()
WebUI.setText(findTestObject('SignInPage/emailField'), GlobalVariable.visualTest)

WebUI.setText(findTestObject('SignInPage/passwordField'), GlobalVariable.password)

WebUI.enhancedClick(findTestObject('SignInPage/signInBtn'))

WebUI.delay(2)

WebUI.waitForElementVisible(findTestObject('TopNavigationMenu/scoutsTab'), 60)
WebUI.enhancedClick(findTestObject('TopNavigationMenu/seasonDrpDwn'))

WebUI.enhancedClick(findTestObject('TopNavigationMenu/seasonDrpDwnValue', [('seasonValue') : (GlobalVariable.data).getValue("seasonDrpDwn", 34)]))

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/scheduleTab'))
WebUI.waitForPageLoad(30)
WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 50, FailureHandling.STOP_ON_FAILURE)

WebUI.enhancedClick(findTestObject('Object Repository/TeamPage/Schedule/Splits/conferenceBtn'))
WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 30)
conference_act = UiCheck.takeSnap(driver, 500,'Schedule_Conference_act.png')
UiCheck.compareImages(UiCheck.loadFile('Schedule_Conference_org.png'), conference_act,'Schedule_Conference_Diff.png')


WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/last5Btn'))
WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 30)
Last5_act = UiCheck.takeSnap(driver, 500,'Schedule_Last5_act.png')
UiCheck.compareImages(UiCheck.loadFile('Schedule_Last5_org.png'), Last5_act,'Schedule_Last5_Diff.png')

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/winsBtn'))
WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 30)
wins_act = UiCheck.takeSnap(driver, 500,'Schedule_wins_act.png')
UiCheck.compareImages(UiCheck.loadFile('Schedule_wins_org.png'), wins_act,'Schedule_wins_Diff.png')

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/lossesBtn'))
WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 30)
losses_act = UiCheck.takeSnap(driver, 500,'Schedule_losses_act.png')
UiCheck.compareImages(UiCheck.loadFile('Schedule_losses_org.png'), losses_act,'Schedule_losses_Diff.png')

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/homeBtn'))
WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 30)
home_act = UiCheck.takeSnap(driver, 500,'Schedule_home_act.png')
UiCheck.compareImages(UiCheck.loadFile('Schedule_home_org.png'), home_act,'Schedule_home_Diff.png')

WebUI.enhancedClick(findTestObject('TeamPage/Schedule/Splits/awayBtn'))
WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 30)
away_act = UiCheck.takeSnap(driver, 500,'Schedule_away_act.png')
UiCheck.compareImages(UiCheck.loadFile('Schedule_away_org.png'), away_act,'Schedule_away_Diff.png')

WebUI.enhancedClick(findTestObject('Object Repository/TeamPage/Schedule/Splits/allGamesBtn'))
WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 30)
allGames_act = UiCheck.takeSnap(driver, 500,'Schedule_all_Games_act.png')
UiCheck.compareImages(UiCheck.loadFile('Schedule_all_Games_org.png'), allGames_act,'Schedule_all_Games_Diff.png')

WebUI.enhancedClick(findTestObject('Boxscore Page/scheduledTabBoxScoreRow1'))
WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 30)
boxScore_act = UiCheck.takeSnap(driver, 500,'Schedule_boxScore_act.png')
UiCheck.compareImages(UiCheck.loadFile('Schedule_boxScore_org.png'), boxScore_act,'Schedule_boxScore_Diff.png')

WebUI.enhancedClick(findTestObject('Boxscore Page/playByPlayTab'))
WebUI.waitForElementNotPresent(findTestObject('Object Repository/TopNavigationMenu/loaderIcon'), 30)
playByPlay_act = UiCheck.takeSnap(driver, 500,'Schedule_playByPlay_act.png')
UiCheck.compareImages(UiCheck.loadFile('Schedule_playByPlay_org.png'), playByPlay_act,'Schedule_playByPlay_Diff.png')

WebUI.closeBrowser()

