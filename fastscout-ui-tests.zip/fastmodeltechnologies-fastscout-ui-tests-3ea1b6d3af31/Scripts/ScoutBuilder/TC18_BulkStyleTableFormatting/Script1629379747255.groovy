import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import java.lang.String


WebUI.openBrowser(GlobalVariable.URL)

WebUI.setText(findTestObject('SignInPage/emailField'), GlobalVariable.email)

WebUI.setText(findTestObject('SignInPage/passwordField'), GlobalVariable.password)

WebUI.enhancedClick(findTestObject('SignInPage/signInBtn'))

WebUI.waitForElementVisible(findTestObject('TopNavigationMenu/scoutsTab'), 60)

WebUI.enhancedClick(findTestObject('TopNavigationMenu/scoutsTab'))

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/newScoutBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/oppTeamDrpdwn'))

WebUI.delay(3)

WebUI.setText(findTestObject('Object Repository/ScoutsPage/NewScoutModal/oppTeamNameTxtFld'), (GlobalVariable.data).getValue("teamName", 8))

WebUI.delay(2)

WebUI.sendKeys(findTestObject('ScoutsPage/NewScoutModal/oppTeamNameTxtFld'), Keys.chord(Keys.ENTER))

WebUI.delay(3)

WebUI.enhancedClick(findTestObject('Object Repository/ScoutsPage/NewScoutModal/seasonDrpDwn'))

WebUI.delay(2)

WebUI.enhancedClick(findTestObject('Object Repository/ScoutsPage/NewScoutModal/seasonDrpDwnValue', [('seasonYear') : (GlobalVariable.data).getValue('seasonDrpDwn', 8)]))

WebUI.delay(3)

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/blankTemplateChkBox'))

WebUI.delay(3)

WebUI.enhancedClick(findTestObject('ScoutsPage/NewScoutModal/createBtn'))

WebUI.delay(3)

WebUI.waitForElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'), 20)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/CumulativeBoxscoreTile/cumulativeBoxscoreTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.delay(1)


WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/CumulativeBoxscoreTile'))
//WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/CumulativeBoxscoreTile/cumBoxscoreSelectAllBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/CumulativeBoxscoreTile/cumBoxscoreSelectAllBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/boldFormatOption'))

def player1Cell1 = WebUI.getCSSValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/CumulativeBoxscoreTile/cumBoxscorePlayerNameCell'), 'font-weight')

WebUI.verifyEqual(player1Cell1, 700)

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/CumulativeBoxscoreTile/cumBoxscorePlayerColumnSelect'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/CumulativeBoxscoreTile/cumBoxscorePlayerColumnSelect'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/boldFormatOption'))
def playerCell2 = WebUI.getCSSValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/CumulativeBoxscoreTile/cumBoxscorePlayerNameCell'), 'font-weight')
WebUI.verifyEqual(playerCell2, 400)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/CumulativeBoxscoreTile/cumBoxscorePlayerNameCell'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/boldFormatOption'))

def player1Cell2 = WebUI.getCSSValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/CumulativeBoxscoreTile/cumBoxscorePlayerNameCell'), 'font-weight')

//this value of 400 is incorrect, change to 700 once issue is resolved.
WebUI.verifyEqual(player1Cell2, 700)

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/CumulativeBoxscoreTile'))

WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'),20)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'),20)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.delay(1)


WebUI.waitForElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'), 0)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'))

//WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'))

WebUI.delay(1)

WebUI.verifyElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamPaceTile/teamPaceTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamPaceTile/teamPaceTile'))

WebUI.delay(1)


WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))


WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/TeamPaceTile'))

//WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamPaceTile/teamPaceTileSelectAllSelector'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamPaceTile/teamPaceTileSelectAllSelector'))

WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/boldFormatOption'), 20)
WebUI.delay(5)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/italicsFormatOption'))
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/italicsFormatOption'))
WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/boldFormatOption'), 20)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/boldFormatOption'))

WebUI.comment(WebUI.getCSSValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamPaceTile/teamPaceTileCell1Value'), 'font-weight'))

def teamPaceCell1 = WebUI.getCSSValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamPaceTile/teamPaceTileCell1Value'), 'font-weight')

WebUI.verifyEqual(teamPaceCell1, 700)
WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/TeamPaceTile'))
//WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamPaceTile/teamPaceTileColumn1Selector'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamPaceTile/teamPaceTileColumn1Selector'))
WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/boldFormatOption'), 20)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/boldFormatOption'))

WebUI.delay(1)

def teamPaceCell2 = WebUI.getCSSValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamPaceTile/teamPaceTileCell1Value'),
	'font-weight')

WebUI.verifyEqual(teamPaceCell2, 400)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamPaceTile/teamPaceTileCell1Value'))
WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/boldFormatOption'), 20)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/boldFormatOption'))

def teamPaceCell3 = WebUI.getCSSValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamPaceTile/teamPaceTileCell1Value'), 'font-weight')

WebUI.verifyEqual(teamPaceCell3, 700)

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/TeamPaceTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))
//Commenting below block due to issue in Points per Table formatting
/*
 * WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/
 * TeamStatsTile/teamStatsTile'))
 *
 * WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/
 * TeamStatsTile/PointsPerPeriodTile/pointsPerPeriodTile'))
 *
 * WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/
 * addSaveTileBtn'))
 *
 * WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/
 * TilesOnReport/PointsPerPeriodTile'))
 *
 * WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/
 * PointsPerPeriodTile/pppTileSelectAllSelector'))
 *
 * WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/
 * TeamStatsTile/PointsPerPeriodTile/pppTileSelectAllSelector'))
 *
 * WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/
 * TileFormattingOptions/boldFormatOption'))
 *
 * def pppTile1 =
 * WebUI.getCSSValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile
 * /PointsPerPeriodTile/pppTitleCell1Value'), 'font-weight')
 *
 * WebUI.verifyEqual(pppTile1, 700)
 *
 * WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/
 * PointsPerPeriodTile/pppTileColumn1Selector'))
 *
 * WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/
 * TeamStatsTile/PointsPerPeriodTile/pppTileColumn1Selector'))
 *
 * WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/
 * TileFormattingOptions/boldFormatOption'))
 *
 * def pppTile2 =
 * WebUI.getCSSValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile
 * /PointsPerPeriodTile/pppTitleCell1Value'), 'font-weight')
 *
 * WebUI.verifyEqual(pppTile2, 400)
 *
 * WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/
 * PointsPerPeriodTile/pppTitleCell1Value'))
 *
 * WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/
 * TeamStatsTile/PointsPerPeriodTile/pppTitleCell1Value'))
 *
 * WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/
 * TileFormattingOptions/boldFormatOption'))
 *
 * def pppTile3 =
 * WebUI.getCSSValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile
 * /PointsPerPeriodTile/pppTitleCell1Value'), 'font-weight')
 *
 * WebUI.verifyEqual(pppTile3, 700)
 *
 * WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/
 * PointsPerPeriodTile'))
 *
 * WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/
 * TileEllipsisMenu/tileEllipsisBtn'))
 *
 * WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/
 * TileEllipsisMenu/deleteTile'))
 */
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamStatSplitsTile/teamStatSplitsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/TeamStatSplitsTile'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/TeamStatSplitsTile'))
//WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamStatSplitsTile/teamStatSplitsTileSelectAllSelector'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamStatSplitsTile/teamStatSplitsTileSelectAllSelector'))
WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/boldFormatOption'), 20)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/boldFormatOption'))

def teamStatSplitsTile1 = WebUI.getCSSValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamStatSplitsTile/teamStatSplitsTileStatCell1'),
	'font-weight')

WebUI.verifyEqual(teamStatSplitsTile1, 700)

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamStatSplitsTile/teamStatSplitsTileStatColumn1Selector'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamStatSplitsTile/teamStatSplitsTileStatColumn1Selector'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/boldFormatOption'))

def teamStatSplitsTile2 = WebUI.getCSSValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamStatSplitsTile/teamStatSplitsTileStatCell1'),
	'font-weight')

WebUI.verifyEqual(teamStatSplitsTile2, 400)

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamStatSplitsTile/teamStatSplitsTileStatCell1'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamStatSplitsTile/teamStatSplitsTileStatCell1'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/boldFormatOption'))

def teamStatSplitsTile3 = WebUI.getCSSValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/TeamStatSplitsTile/teamStatSplitsTileStatCell1'),
	'font-weight')

WebUI.verifyEqual(teamStatSplitsTile3, 700)

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/TeamStatSplitsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/teamStatsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/FastScoutFactorsTile/fastScoutFactorsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEditor/addSaveTileBtn'))

WebUI.verifyElementVisible(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/FastScoutFactorsTile'))

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/FastScoutFactorsTile'))
//WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/FastScoutFactorsTile/FFTileSelectAllSelector'))
WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/FastScoutFactorsTile/FFTileSelectAllSelector'),20)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/FastScoutFactorsTile/FFTileSelectAllSelector'))
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/italicsFormatOption'))
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/italicsFormatOption'))
WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/boldFormatOption'), 20)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/boldFormatOption'))

def ffTile1 = WebUI.getCSSValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/FastScoutFactorsTile/FFTileStatCell'), 
    'font-weight')

WebUI.verifyEqual(ffTile1, 700)

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/FastScoutFactorsTile/FFTileColumn1Selector'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/FastScoutFactorsTile/FFTileColumn1Selector'))
WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/boldFormatOption'), 20)
WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/boldFormatOption'))

def ffTile2 = WebUI.getCSSValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/FastScoutFactorsTile/FFTileStatCell'), 
    'font-weight')

WebUI.verifyEqual(ffTile2, 400)

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/FastScoutFactorsTile/FFTileStatCell'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/FastScoutFactorsTile/FFTileStatCell'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileFormattingOptions/boldFormatOption'))

def ffTile3 = WebUI.getCSSValue(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TeamStatsTile/FastScoutFactorsTile/FFTileStatCell'), 
    'font-weight')

WebUI.verifyEqual(ffTile3, 700)

WebUI.mouseOver(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TilesOnReport/FastScoutFactorsTile'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/tileEllipsisBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/Tiles/TileEllipsisMenu/deleteTile'))

// Closing report, clean up
WebUI.waitForElementClickable(findTestObject('ScoutsPage/ScoutBuilder/TopMenu/doneBtn'), 0)

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutBuilder/TopMenu/doneBtn'))

WebUI.delay(2)

WebUI.waitForElementVisible(findTestObject('ScoutsPage/SubNavigation/opponentScoutsTab'), 0)

WebUI.enhancedClick(findTestObject('ScoutsPage/SubNavigation/opponentScoutsTab'))

WebUI.mouseOver(findTestObject('ScoutsPage/OpponentScouts/oppScoutNameFromGrid', [('scoutName') : (GlobalVariable.data).getValue(
                'teamName', 8)]))

WebUI.enhancedClick(findTestObject('ScoutsPage/OpponentScouts/scoutContextEllipsisBtn', [('scoutName') : (GlobalVariable.data).getValue(
                'teamName', 8)]))

WebUI.enhancedClick(findTestObject('ScoutsPage/ScoutContextMenu/archiveBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/SubNavigation/archivedTab'))

WebUI.mouseOver(findTestObject('ScoutsPage/Archived/archivedScouts1stRow'))

WebUI.enhancedClick(findTestObject('ScoutsPage/Archived/scoutArchiveEllipsisIcn'))

WebUI.waitForElementClickable(findTestObject('ScoutsPage/Archived/deleteBtn'), 0)

WebUI.mouseOver(findTestObject('ScoutsPage/Archived/deleteBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/Archived/deleteBtn'))

WebUI.enhancedClick(findTestObject('ScoutsPage/Archived/confirmDeleteScoutBtn'))

WebUI.closeBrowser()

