package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object URL
     
    /**
     * <p></p>
     */
    public static Object email
     
    /**
     * <p></p>
     */
    public static Object password
     
    /**
     * <p>Profile default : user with no feature</p>
     */
    public static Object email2
     
    /**
     * <p>Profile default : user with no features</p>
     */
    public static Object password2
     
    /**
     * <p>Profile default : email scout role
Profile EUROM : email scout role
Profile NAIAM : email scout role
Profile NAIAW : email scout role
Profile NBA : email scout role
Profile NBAG : email scout role
Profile NCAAB : email scout role
Profile NCAABII : email scout role
Profile SERIEAM : email scout role
Profile WNBA : email scout role
Profile WNCAAB : email scout role
Profile WNCAABII : email scout role</p>
     */
    public static Object emailscout
     
    /**
     * <p></p>
     */
    public static Object passwordscout
     
    /**
     * <p></p>
     */
    public static Object primaryColor
     
    /**
     * <p></p>
     */
    public static Object allTeams1
     
    /**
     * <p></p>
     */
    public static Object environment
     
    /**
     * <p></p>
     */
    public static Object data
     
    /**
     * <p></p>
     */
    public static Object playerScout
     
    /**
     * <p></p>
     */
    public static Object playerPwd
     
    /**
     * <p></p>
     */
    public static Object visualTest
     

    /**
     * <p>Profile EUROM : user for Simultaneous Editing Feature</p>
     */
    public static Object emailEurom
     


    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += TestCaseMain.getParsedValues(RunConfiguration.getOverridingParameters())
    
            URL = selectedVariables['URL']
            email = selectedVariables['email']
            password = selectedVariables['password']
            email2 = selectedVariables['email2']
            password2 = selectedVariables['password2']
            emailscout = selectedVariables['emailscout']
            passwordscout = selectedVariables['passwordscout']
            primaryColor = selectedVariables['primaryColor']
            allTeams1 = selectedVariables['allTeams1']
            environment = selectedVariables['environment']
            data = selectedVariables['data']
            playerScout = selectedVariables['playerScout']
            playerPwd = selectedVariables['playerPwd']
            visualTest = selectedVariables['visualTest']
            emailEurom = selectedVariables['emailEurom']

            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
