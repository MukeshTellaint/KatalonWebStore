
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */



def static "common.Actions.signInUser1"() {
    (new common.Actions()).signInUser1()
}


def static "common.Actions.signInUser1Local"() {
    (new common.Actions()).signInUser1Local()
}


def static "common.Actions.signInUserScout"() {
    (new common.Actions()).signInUserScout()
}


def static "common.Actions.signInUserScoutLocal"() {
    (new common.Actions()).signInUserScoutLocal()
}


def static "common.Actions.createOpponentScoutBlankTemplate"() {
    (new common.Actions()).createOpponentScoutBlankTemplate()
}


def static "common.Actions.archiveOpponentScout"() {
    (new common.Actions()).archiveOpponentScout()
}


def static "common.Actions.deleteScout"() {
    (new common.Actions()).deleteScout()
}


def static "common.Actions.addSectionHeaderTile"() {
    (new common.Actions()).addSectionHeaderTile()
}


def static "common.Actions.editSectionHeaderTile"() {
    (new common.Actions()).editSectionHeaderTile()
}


def static "common.Actions.deleteSectionHeaderTile"() {
    (new common.Actions()).deleteSectionHeaderTile()
}


def static "common.Actions.addFastScoutFactorsTile"() {
    (new common.Actions()).addFastScoutFactorsTile()
}
